#!/usr/bin/env bash
# Membuat SFX placeholder sintetis (WAV) dengan ffmpeg. Ganti file di public/sounds/ dengan SFX asli
# memakai nama file yang sama. Jalankan: bash tools/make-placeholder-sounds.sh
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=public/sounds
mkdir -p "$OUT"

tone() { # nama frekuensi durasi volume
  ffmpeg -hide_banner -loglevel error -y -f lavfi -i "sine=frequency=$2:duration=$3" -af "volume=$4,afade=t=out:st=0:d=$3" "$OUT/$1.wav"
}
noise() { # nama durasi filter volume
  ffmpeg -hide_banner -loglevel error -y -f lavfi -i "anoisesrc=d=$2:c=pink:r=44100" -af "$3,volume=$4,afade=t=out:st=0:d=$2" "$OUT/$1.wav"
}

tone ding 1320 0.5 0.5
tone ting 1760 0.35 0.4
tone pop 520 0.12 0.7
tone beep 880 0.25 0.4
tone boing 240 0.4 0.6
tone heart 660 0.3 0.4
tone zap 120 0.35 0.7
tone scratch 1500 0.2 0.3
noise whoosh 0.5 "highpass=f=600,lowpass=f=5000" 0.8
noise step 0.12 "lowpass=f=700" 1.5
noise drip 0.1 "highpass=f=1500" 0.6
noise sigh 0.9 "lowpass=f=1200" 0.5
noise knock 0.15 "lowpass=f=400" 1.6

# Narasi placeholder (hening) hanya jika file asli belum ada.
if [ ! -f public/narasi.mp3 ]; then
  ffmpeg -hide_banner -loglevel error -y -f lavfi -i anullsrc=r=44100:cl=mono -t 65.2 -q:a 9 public/narasi.mp3
  echo "PERINGATAN: public/narasi.mp3 adalah placeholder HENING. Ganti dengan narasi asli."
fi
echo "Selesai: SFX placeholder di $OUT"
