# Kenapa Kita Susah Berak Kalau di Luar Rumah? — Proyek Remotion

Video animasi edukasi-komedi ±65 detik, 1080×1920, 30 fps, tanpa header. Remotion 4.0.306 + React + TypeScript.

## Status jujur (baca dulu)
- **Belum pernah dirender atau diuji di Remotion.** Kode ditulis dan dicek sintaksnya (36 file) serta logika data (beat, caption, durasi), tetapi `npm install`, `tsc` penuh, preview, dan render belum bisa dijalankan di lingkungan pembuatan. Kemungkinan ada kesalahan visual atau tipe kecil yang baru terlihat di preview.
- **`public/narasi.mp3` adalah placeholder HENING.** Taruh narasi asli dengan nama yang sama.
- **SFX di `public/sounds/` adalah nada sintetis.** Ganti dengan SFX asli, nama file sama.
- **Timing kata dan batas beat adalah ESTIMASI** dari SRT per kalimat. Sinkronisasi belum final sebelum dicek dengan audio asli.

## Menjalankan
```
npm install
npm run dev        # preview di browser (Remotion Studio)
npm run typecheck  # cek TypeScript
npm run render     # hasil: out/shy-bowel.mp4
```
Butuh Node.js 18+ (disarankan LTS). Render pertama mengunduh Chrome Headless otomatis.

## Menyetel sinkronisasi
- `src/data/config.ts`: `AUDIO_OFFSET` (detik, geser semua), `AUDIO_END_SECONDS` (akhir narasi asli), `END_HOLD_SECONDS`.
- `src/data/beats.ts`: `startSec` tiap beat (urutan 12 beat tetap).
- `captions.srt` dan `src/data/captions.ts` (`SRT_SOURCE`): ganti dengan SRT dari audio asli. Waktu per kata dibagi proporsional jumlah karakter.
- Aksi di dalam beat (label muncul, SFX) memakai frame relatif beat: lihat `src/data/sfx.ts` dan angka `at=` di `src/beats/*.tsx`.

## Struktur
- `src/data/layout.ts`: koordinat eksplisit 1080×1920 (sumber kebenaran layout).
- `src/components/MainCharacter.tsx` + `CharacterExpressions.tsx`: satu desain karakter, ekspresi dan pose sebagai prop.
- `src/beats/Beat01..12.tsx`: satu file per beat. `src/Video.tsx` menyusunnya dengan `Sequence`, ditambah narasi, SFX, subtitle.
- `tools/make-placeholder-sounds.sh`: membuat ulang SFX placeholder (butuh ffmpeg).

## Catatan desain
- Tidak ada header, judul permanen, nomor scene, atau progres bar.
- Karakter digambar ulang sebagai SVG mengikuti character sheet (bukan memakai file gambar referensi), jadi kemiripan perlu dinilai di preview.
- Beat 04 memuat kalimat tambahan dari SRT ("Padahal perut udah mules...") sebagai cut balik ke wajah berkeringat.
