import React from 'react';
import {Sequence, interpolate, useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {MarkBurst} from '../components/Effects';
import {SeatedCharacter} from '../components/MainCharacter';
import {PublicBathroom} from '../components/PublicBathroom';
import {Silhouette} from '../components/ToiletEnvironment';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

const L = LAYOUT.b04;

// Beat 04a: berusaha -> berhenti -> melirik pintu -> hela napas. Slow zoom-out.
const Part: React.FC<{duration: number}> = ({duration}) => {
  const f = useCurrentFrame();
  const trying = f < 45;
  const glance = interpolate(f, [55, 75], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const sigh = interpolate(f, [88, 108], [0, 6], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Camera
      duration={duration}
      from={{scale: 1.3, x: -30, y: -50}}
      to={{scale: 1.06, x: 0, y: 0}}
      originX={520}
      originY={800}
    >
      <PublicBathroom variant="stall" />
      <Silhouette box={L.silhouette} dx={Math.sin(f / 18) * 10} opacity={0.5} />
      <SeatedCharacter
        box={L.character}
        tone="cool"
        expression={trying ? 'tense' : 'flat'}
        arms={trying ? 'fists' : 'lap'}
        sweat={trying}
        tremble={trying ? 2.5 : 0}
        look={glance}
        faceShift={glance * 18}
        tilt={sigh}
        bob={trying ? 4 : 3}
      />
      <MarkBurst box={L.mark} text="!!" at={60} />
    </Camera>
  );
};

// Beat 04b: kalimat tambahan di SRT ("Padahal perut udah mules, keringat bercucuran...")
// -> cut balik ke wajah berkeringat (callback ke Beat 03).
const PartB: React.FC<{duration: number}> = ({duration}) => {
  const f = useCurrentFrame();
  return (
    <Camera
      duration={duration}
      from={{scale: 1.18, x: -20, y: -40}}
      to={{scale: 1.3, x: -30, y: -70}}
      originX={520}
      originY={800}
      shake={3}
    >
      <PublicBathroom variant="stall" />
      <Silhouette box={L.silhouette} dx={Math.sin(f / 14) * 8} opacity={0.5} />
      <SeatedCharacter
        box={L.character}
        tone="cool"
        expression="tense"
        arms="fists"
        sweat
        tremble={3}
        bob={5}
        tilt={Math.sin(f * 0.5) * 2}
      />
    </Camera>
  );
};

export const Beat04: React.FC<BeatProps> = ({duration}) => {
  const CUT = 117;
  return (
    <>
      <Sequence from={0} durationInFrames={CUT} name="b04a">
        <Part duration={CUT} />
      </Sequence>
      <Sequence from={CUT} durationInFrames={Math.max(1, duration - CUT)} name="b04b">
        <PartB duration={Math.max(1, duration - CUT)} />
      </Sequence>
    </>
  );
};
