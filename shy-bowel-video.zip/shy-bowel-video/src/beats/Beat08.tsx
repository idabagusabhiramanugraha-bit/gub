import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BrainIllustration} from '../components/BrainIllustration';
import {Camera} from '../components/Camera';
import {DigestiveSystem} from '../components/DigestiveSystem';
import {InformationLabel} from '../components/InformationLabel';
import {PelvicMuscleIllustration} from '../components/PelvicMuscleIllustration';
import {PsychBackground} from '../components/ToiletEnvironment';
import {LAYOUT} from '../data/layout';
import {COLORS} from '../styles/theme';
import type {BeatProps} from './types';

// Beat 08 — Otak -> sinyal merah -> otot dasar panggul menegang. Ilustrasi edukatif sederhana.
export const Beat08: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b08;
  const bodyS = spring({frame: f, fps, config: {damping: 13, stiffness: 140, mass: 0.8}});
  const signal = interpolate(f, [20, 66], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.quad),
  });
  const insetS = f < 66 ? 0 : spring({frame: f - 66, fps, config: {damping: 11, stiffness: 160, mass: 0.7}});
  const tension = interpolate(f, [72, 100], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const glow = f >= 62 ? 0.5 + 0.5 * Math.sin((f - 62) / 3) : 0;
  const path = 'M 240 215 C 240 300 236 420 240 560';

  return (
    <Camera
      duration={duration}
      from={{scale: 1.05, x: 0, y: 0}}
      to={{scale: 1.2, x: -30, y: -40}}
      originX={330}
      originY={900}
    >
      <PsychBackground />
      {/* siluet tubuh */}
      <svg
        viewBox="0 0 480 900"
        style={{
          position: 'absolute',
          left: L.body.x,
          top: L.body.y,
          width: L.body.w,
          height: L.body.h,
          overflow: 'visible',
          transform: `scale(${bodyS})`,
          transformOrigin: '50% 40%',
        }}
      >
        <ellipse cx={240} cy={130} rx={100} ry={110} fill="#F4F6FA" stroke={COLORS.ink} strokeWidth={7} />
        <path
          d="M 120 262 C 60 284 50 420 70 560 L 100 760 L 220 760 L 240 650 L 260 760 L 380 760 L 410 560 C 430 420 420 284 360 262 Z"
          fill="#F4F6FA"
          stroke={COLORS.ink}
          strokeWidth={7}
          strokeLinejoin="round"
        />
        {/* area panggul di-highlight */}
        <ellipse cx={240} cy={600} rx={96} ry={70} fill={COLORS.red} opacity={0.18 + 0.28 * glow} />
        {/* sinyal merah */}
        <path d={path} fill="none" stroke={COLORS.red} strokeWidth={14} strokeLinecap="round" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - signal} />
        {signal > 0.95 ? (
          <path d="M 205 560 L 240 618 L 275 560" fill="none" stroke={COLORS.red} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
        ) : null}
      </svg>
      <DigestiveSystem box={{x: L.body.x + 150, y: L.body.y + 300, w: 180, h: 260}} opacity={0.55 * bodyS} scale={bodyS} />
      <BrainIllustration box={{x: L.body.x + 150, y: L.body.y + 55, w: 180, h: 140}} scale={bodyS * (1 + 0.04 * Math.sin(f * 0.5))} />

      {/* inset otot */}
      <div
        style={{
          position: 'absolute',
          left: L.inset.x,
          top: L.inset.y,
          width: L.inset.w,
          height: L.inset.h,
          borderRadius: '50%',
          overflow: 'hidden',
          border: `8px solid ${COLORS.red}`,
          boxShadow: '0 10px 0 rgba(0,0,0,0.25)',
          transform: `scale(${insetS})`,
          background: '#FFF3F0',
        }}
      >
        <PelvicMuscleIllustration box={{x: 0, y: 0, w: L.inset.w - 16, h: L.inset.h - 16}} tension={tension} />
      </div>
      <svg width={1080} height={1920} style={{position: 'absolute', left: 0, top: 0, opacity: insetS}}>
        <path d="M 330 1000 L 566 930 L 566 1040 Z" fill={COLORS.red} stroke={COLORS.ink} strokeWidth={5} strokeLinejoin="round" />
      </svg>

      <InformationLabel box={L.label} text="OTOT IKUT TEGANG!" at={88} tilt={4} fontSize={42} />
    </Camera>
  );
};
