import React from 'react';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {InformationLabel} from '../components/InformationLabel';
import {SeatedCharacter} from '../components/MainCharacter';
import {PublicBathroom} from '../components/PublicBathroom';
import {Silhouette} from '../components/ToiletEnvironment';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 07 — Tiga gangguan. Scene utama = karakter gugup di bilik; quick-cut insert:
// wastafel (orang lewat), pintu (gagang bergoyang), bayangan kaki di celah pintu.
// Label muncul satu per satu mengikuti kata di narasi (estimasi, cek ulang dengan audio asli).
const SINK = {from: 66, to: 86};
const DOOR = {from: 110, to: 130};
const FEET = {from: 150, to: 172};

export const Beat07: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b07;
  const look = Math.sin(f / 12);

  const inSink = f >= SINK.from && f < SINK.to;
  const inDoor = f >= DOOR.from && f < DOOR.to;
  const inFeet = f >= FEET.from && f < FEET.to;

  return (
    <AbsoluteFill>
      <Camera
        duration={duration}
        from={{scale: 1.06, x: 0, y: 0}}
        to={{scale: 1.14, x: -10, y: -20}}
        originX={370}
        originY={870}
        shake={3}
      >
        <PublicBathroom variant="stall" />
        <SeatedCharacter
          box={L.character}
          tone="cool"
          expression="shocked"
          arms="lap"
          sweat
          tremble={1.5}
          look={look}
          faceShift={look * 32}
          bob={3}
        />
      </Camera>

      {inSink ? (
        <Sequence from={SINK.from} durationInFrames={SINK.to - SINK.from} name="sink">
          <Camera duration={SINK.to - SINK.from} from={{scale: 1.05, x: 0, y: 0}} to={{scale: 1.12, x: -20, y: 0}} shake={2}>
            <PublicBathroom variant="sink" />
            <Silhouette
              box={{x: 300, y: 380, w: 300, h: 980}}
              dx={-700 + (f - SINK.from) * 60}
              opacity={0.7}
            />
          </Camera>
        </Sequence>
      ) : null}

      {inDoor ? (
        <Sequence from={DOOR.from} durationInFrames={DOOR.to - DOOR.from} name="door">
          <Camera duration={DOOR.to - DOOR.from} from={{scale: 1.08, x: 0, y: 0}} to={{scale: 1.2, x: -30, y: -20}} originX={560} originY={840} shake={5}>
            <PublicBathroom variant="door" handleAngle={Math.sin(f * 1.6) * 16} />
          </Camera>
        </Sequence>
      ) : null}

      {inFeet ? (
        <Sequence from={FEET.from} durationInFrames={FEET.to - FEET.from} name="feet">
          <Camera duration={FEET.to - FEET.from} from={{scale: 1.1, x: 0, y: 0}} to={{scale: 1.3, x: 0, y: -80}} originX={540} originY={1200}>
            <PublicBathroom variant="stall" shadowFeet />
            <Silhouette box={{x: 700, y: 360, w: 300, h: 980}} opacity={0.35} />
          </Camera>
        </Sequence>
      ) : null}

      <InformationLabel box={L.label1} text="SUARA ORANG LEWAT" at={70} tilt={-3} fontSize={38} />
      <InformationLabel box={L.label2} text="TAKUT PINTU KEBUKA" at={116} tilt={2} fontSize={38} />
      <InformationLabel box={L.label3} text="ADA YANG NUNGGUIN" at={156} tilt={-2} fontSize={38} />
    </AbsoluteFill>
  );
};
