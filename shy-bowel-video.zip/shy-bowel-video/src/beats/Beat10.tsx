import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {FloatHeart} from '../components/Effects';
import {SeatedCharacter} from '../components/MainCharacter';
import {PublicBathroom} from '../components/PublicBathroom';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 10 — Punchline utama: quick zoom-in, mata menyipit, mengangguk kecil, lalu hati kecil (kontras).
export const Beat10: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b10;
  const nod = f >= 36 && f < 56 ? Math.sin(((f - 36) / 20) * Math.PI) * 7 : 0;
  const settled = f >= 58;
  const turn = interpolate(f, [8, 22], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <Camera
      duration={duration}
      from={{scale: 1.0, x: 0, y: 0}}
      to={{scale: 1.3, x: -30, y: -60}}
      originX={400}
      originY={800}
      easeFrames={14}
    >
      <PublicBathroom variant="stall" />
      <SeatedCharacter
        box={L.character}
        tone="cool"
        expression={settled ? 'proud' : 'suspicious'}
        arms="lap"
        look={-1 + turn * 2}
        faceShift={-20 + turn * 40}
        tilt={nod}
        bob={2}
      />
      <FloatHeart x={L.heart.x} y={L.heart.y} at={62} size={L.heart.w} />
    </Camera>
  );
};
