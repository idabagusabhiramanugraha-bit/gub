import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Camera} from '../components/Camera';
import {DigestiveSystem} from '../components/DigestiveSystem';
import {HouseIcon, Sparkle} from '../components/Effects';
import {HomeBathroom} from '../components/HomeBathroom';
import {InformationLabel} from '../components/InformationLabel';
import {SeatedCharacter} from '../components/MainCharacter';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 06 — Rumah aman & nyaman: pencahayaan hangat, napas rileks, pencernaan muncul sederhana.
export const Beat06: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b06;
  const houseS = f < 20 ? 0 : spring({frame: f - 20, fps, config: {damping: 10, stiffness: 150, mass: 0.7}});
  const gutS = f < 60 ? 0 : spring({frame: f - 60, fps, config: {damping: 12, stiffness: 140, mass: 0.7}});
  return (
    <Camera
      duration={duration}
      from={{scale: 1.06, x: 20, y: 0}}
      to={{scale: 1.12, x: -20, y: -16}}
      originX={450}
      originY={860}
    >
      <HomeBathroom glow={1} />
      <SeatedCharacter box={L.character} tone="warm" paper={false} expression="calm" arms="lap" bob={5} tilt={Math.sin(f / 30) * 2} />
      <HouseIcon box={L.house} scale={houseS} />
      <InformationLabel box={L.label} text="AMAN & NYAMAN" variant="blue" at={40} tilt={-4} fontSize={52} />
      <DigestiveSystem box={L.digestive} scale={gutS} opacity={Math.min(1, gutS)} />
      <Sparkle x={150} y={680} size={34} />
      <Sparkle x={610} y={620} size={26} phase={12} />
      <Sparkle x={560} y={1000} size={30} phase={5} />
    </Camera>
  );
};
