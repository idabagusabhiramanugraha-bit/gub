import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {ShakeLines} from '../components/Effects';
import {SeatedCharacter} from '../components/MainCharacter';
import {PublicBathroom} from '../components/PublicBathroom';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 03 — Kebelet: wajah tegang, keringat, kepalan, getaran. Medium close-up + camera shake kecil.
export const Beat03: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b03;
  return (
    <Camera
      duration={duration}
      from={{scale: 1.08, x: 0, y: 0}}
      to={{scale: 1.22, x: -10, y: -40}}
      originX={540}
      originY={800}
      shake={4}
    >
      <PublicBathroom variant="stall" />
      <SeatedCharacter
        box={L.character}
        tone="cool"
        expression="tense"
        arms="fists"
        sweat
        tremble={3}
        bob={6}
        tilt={Math.sin(f * 0.6) * 3}
      />
      <ShakeLines box={L.shake} />
    </Camera>
  );
};
