import React from 'react';
import {Easing, Freeze, interpolate, useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {Sparkle} from '../components/Effects';
import {HomeBathroom} from '../components/HomeBathroom';
import {MainCharacter} from '../components/MainCharacter';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

const RAISE_AT = 183; // ± saat "Pantat juga butuh privasi" (estimasi)
const FREEZE_FRAMES = 15;

const Scene: React.FC<{duration: number}> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b12;
  const raise = interpolate(f, [RAISE_AT, RAISE_AT + 10], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.back(2)),
  });
  return (
    <Camera
      duration={duration}
      from={{scale: 1.05, x: 20, y: 0}}
      to={{scale: 1.16, x: -20, y: -30}}
      originX={470}
      originY={800}
    >
      <HomeBathroom glow={1} />
      <MainCharacter
        box={L.character}
        expression="proud"
        arms="chinHip"
        armsTo="raise"
        armsT={raise}
        faceShift={10}
        tilt={-3}
        bob={3}
      />
      <Sparkle x={L.sparkle.x} y={L.sparkle.y} size={44} />
      <Sparkle x={L.sparkle.x + 150} y={L.sparkle.y + 170} size={30} phase={8} />
      <Sparkle x={200} y={640} size={34} phase={15} />
      {f >= RAISE_AT ? <Sparkle x={820} y={500} size={54} phase={f} /> : null}
    </Camera>
  );
};

// Beat 12 — Closing: pose percaya diri, tangan terangkat saat punchline, freeze frame di akhir.
export const Beat12: React.FC<BeatProps> = ({duration}) => {
  const frame = useCurrentFrame();
  const freezeAt = Math.max(0, duration - FREEZE_FRAMES);
  const scene = <Scene duration={duration} />;
  return frame >= freezeAt ? <Freeze frame={freezeAt}>{scene}</Freeze> : scene;
};
