import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {ComfortLines, Sparkle} from '../components/Effects';
import {HomeBathroom} from '../components/HomeBathroom';
import {SeatedCharacter} from '../components/MainCharacter';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 01 — Hook: toilet rumah hangat, karakter smug. Slow push-in ke wajah.
export const Beat01: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b01;
  const t = (1 - Math.cos(f / 24)) / 2; // tangan naik-turun santai
  return (
    <Camera
      duration={duration}
      from={{scale: 1.06, x: 0, y: 0}}
      to={{scale: 1.3, x: -30, y: -90}}
      originX={519}
      originY={776}
    >
      <HomeBathroom glow={0.85} />
      <SeatedCharacter
        box={L.character}
        tone="warm"
        expression="smug"
        arms="lap"
        armsTo="chin"
        armsT={t}
        look={0.3}
        tilt={-4}
        bob={3}
      />
      <Sparkle x={L.sparkle.x} y={L.sparkle.y} size={44} />
      <Sparkle x={L.sparkle.x + 110} y={L.sparkle.y + 150} size={28} phase={9} />
      <Sparkle x={210} y={600} size={30} phase={17} />
      <ComfortLines x={720} y={560} size={110} rotate={-10} />
    </Camera>
  );
};
