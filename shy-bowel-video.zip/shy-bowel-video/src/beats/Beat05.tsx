import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BrainIllustration} from '../components/BrainIllustration';
import {Camera} from '../components/Camera';
import {ComfortLines, WarningSign} from '../components/Effects';
import {InformationLabel} from '../components/InformationLabel';
import {MainCharacter} from '../components/MainCharacter';
import {PsychBackground} from '../components/ToiletEnvironment';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 05 — Otak waspada: quick push-in ke kepala, otak muncul (scale) dan berdenyut.
export const Beat05: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b05;
  const pop = f < 14 ? 0 : spring({frame: f - 14, fps, config: {damping: 9, stiffness: 170, mass: 0.7}});
  const pulse = 1 + 0.045 * Math.sin(f * 0.55);
  return (
    <Camera
      duration={duration}
      from={{scale: 1.0, x: 0, y: 0}}
      to={{scale: 1.2, x: 0, y: -20}}
      originX={420}
      originY={995}
      easeFrames={24}
    >
      <PsychBackground />
      <MainCharacter box={L.character} view="bust" expression="thinking" arms="chin" look={1} lookY={-1} tilt={-3} bob={2} />
      <BrainIllustration box={L.brain} scale={pop * pulse} />
      <ComfortLines x={640} y={380} size={110} rotate={20} />
      <WarningSign box={L.warn} at={26} />
      <InformationLabel box={L.bubble} text="OTAK LANGSUNG WASPADA!" variant="bubble" at={30} fontSize={44} />
    </Camera>
  );
};
