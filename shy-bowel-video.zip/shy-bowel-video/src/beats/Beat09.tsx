import React from 'react';
import {useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {MarkBurst} from '../components/Effects';
import {MainCharacter} from '../components/MainCharacter';
import {PublicBathroom} from '../components/PublicBathroom';
import {Toilet} from '../components/ToiletEnvironment';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 09 — Punchline pertama: karakter menyilangkan tangan, menyalahkan toilet. Slow push-in.
export const Beat09: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b09;
  return (
    <Camera
      duration={duration}
      from={{scale: 1.05, x: 0, y: 0}}
      to={{scale: 1.15, x: -20, y: -10}}
      originX={400}
      originY={900}
    >
      <PublicBathroom variant="stall" />
      <Toilet box={L.toilet} wobble={f > 20 ? Math.sin(f / 5) * 0.8 : 0} />
      <MainCharacter
        box={L.character}
        expression="grumpy"
        arms="crossed"
        faceShift={26}
        look={1}
        tilt={f < 24 ? 0 : 6}
        bob={2}
      />
      <MarkBurst box={L.hmph} text="Hmph!" at={8} color={COLORS_WHITE} fontSize={84} rotate={-6} />
    </Camera>
  );
};

const COLORS_WHITE = '#FFFFFF';
