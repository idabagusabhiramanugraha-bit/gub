export type BeatProps = {
  /** Durasi beat dalam frame (dari data/beats.ts). */
  duration: number;
};
