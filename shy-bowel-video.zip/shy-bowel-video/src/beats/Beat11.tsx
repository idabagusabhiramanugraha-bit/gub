import React from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Camera} from '../components/Camera';
import {Sparkle} from '../components/Effects';
import {MainCharacter} from '../components/MainCharacter';
import {PsychBackground} from '../components/ToiletEnvironment';
import {LAYOUT} from '../data/layout';
import {COLORS, FONT_FAMILY} from '../styles/theme';
import type {BeatProps} from './types';

// Beat 11 — Nama fenomena: tulisan besar pop-in, karakter menunjuk dengan tongkat dan mengangguk.
export const Beat11: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b11;
  const pop = spring({frame: f - 6, fps, config: {damping: 9, stiffness: 170, mass: 0.6}});
  const point = interpolate(f, [14, 26], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.back(2)),
  });
  const nod = f > 30 ? Math.sin((f - 30) / 5) * 3 : 0;
  return (
    <Camera
      duration={duration}
      from={{scale: 1.05, x: 0, y: 0}}
      to={{scale: 1.12, x: -10, y: -10}}
      originX={540}
      originY={760}
    >
      <PsychBackground warmAccent />
      <div
        style={{
          position: 'absolute',
          left: L.title.x,
          top: L.title.y,
          width: L.title.w,
          height: L.title.h,
          transform: `scale(${Math.max(0, pop)}) rotate(${-3 + (1 - Math.min(1, pop)) * 6}deg)`,
          transformOrigin: '50% 50%',
        }}
      >
        <svg viewBox="0 0 900 420" style={{position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', overflow: 'visible'}}>
          <path
            d="M 40 80 Q 20 20 120 24 L 790 8 Q 880 8 876 90 L 888 330 Q 890 408 800 404 L 110 414 Q 24 418 30 330 Z"
            fill={COLORS.yellow}
            stroke={COLORS.ink}
            strokeWidth={9}
            strokeLinejoin="round"
          />
        </svg>
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            fontFamily: FONT_FAMILY,
            fontWeight: 900,
            fontSize: 138,
            lineHeight: 1.0,
            color: COLORS.ink,
            textAlign: 'center',
          }}
        >
          <span>SHY BOWEL</span>
          <span>SYNDROME</span>
        </div>
      </div>
      <MainCharacter
        box={L.character}
        expression="serious"
        arms="relax"
        armsTo="point"
        armsT={point}
        pointer={point > 0.9}
        flip
        faceShift={-12}
        look={-1}
        tilt={nod}
        bob={2}
      />
      <Sparkle x={150} y={780} size={30} phase={4} />
      <Sparkle x={930} y={260} size={36} phase={11} />
    </Camera>
  );
};
