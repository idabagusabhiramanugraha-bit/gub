import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {Camera} from '../components/Camera';
import {MarkBurst} from '../components/Effects';
import {MainCharacter} from '../components/MainCharacter';
import {PublicBathroom} from '../components/PublicBathroom';
import {LAYOUT} from '../data/layout';
import type {BeatProps} from './types';

// Beat 02 — Kontras: pintu TOILET UMUM. Karakter berjalan, berhenti, curiga. Slight zoom-in.
export const Beat02: React.FC<BeatProps> = ({duration}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b02;
  const WALK_END = 46;
  const slide = interpolate(f, [0, WALK_END], [380, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });
  const doubt = interpolate(f, [WALK_END, WALK_END + 14], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const walking = f < WALK_END;
  return (
    <Camera
      duration={duration}
      from={{scale: 1.06, x: 0, y: 0}}
      to={{scale: 1.2, x: -40, y: -30}}
      originX={700}
      originY={860}
    >
      <PublicBathroom variant="door" handleAngle={doubt * -8} />
      <MainCharacter
        box={{...L.character, x: L.character.x + slide}}
        expression={f < 48 ? 'smug' : 'suspicious'}
        arms="relax"
        armsTo="hips"
        armsT={doubt}
        walk={walking ? f : undefined}
        faceShift={-40}
        look={-1}
        tilt={walking ? 0 : -4}
        bob={walking ? 0 : 2}
      />
      <MarkBurst box={L.mark} text="!?" at={52} />
    </Camera>
  );
};
