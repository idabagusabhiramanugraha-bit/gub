import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CAPTION_PAGES, KEYWORDS} from '../data/captions';
import {SUBTITLE} from '../data/layout';
import {COLORS, FONT_FAMILY, outlineShadow} from '../styles/theme';

const normalize = (w: string): string => w.toLowerCase().replace(/[^a-z]/g, '');

/** Subtitle di area bawah: maksimal dua baris, highlight mengikuti kata yang sedang diucapkan. */
export const Subtitle: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const page = CAPTION_PAGES.find((p) => frame >= p.startFrame && frame < p.endFrame);
  if (!page) {
    return null; // tidak ada subtitle yang tertinggal setelah audio selesai
  }

  const local = frame - page.startFrame;
  const pop = spring({frame: local, fps, config: {damping: 14, stiffness: 240, mass: 0.5}});
  const scale = 0.94 + 0.06 * pop;

  let active = 0;
  page.words.forEach((w, i) => {
    if (frame >= w.startFrame) {
      active = i;
    }
  });

  const fontSize = page.emphasis ? 70 : 60;
  const show = (t: string): string => (page.emphasis ? t.toUpperCase().replace(/\.$/, '!') : t);

  return (
    <div
      style={{
        position: 'absolute',
        left: SUBTITLE.x,
        top: SUBTITLE.y,
        width: SUBTITLE.w,
        height: SUBTITLE.h,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transform: `scale(${scale})`,
      }}
    >
      <div
        style={{
          background: 'rgba(10,12,20,0.58)',
          borderRadius: 40,
          padding: '20px 34px',
          textAlign: 'center',
          fontFamily: FONT_FAMILY,
          fontWeight: 900,
          fontSize,
          lineHeight: 1.18,
          color: COLORS.white,
          textShadow: outlineShadow(COLORS.ink, 3),
          maxWidth: SUBTITLE.w,
          boxSizing: 'border-box',
        }}
      >
        {page.words.map((w, i) => {
          const isKey = KEYWORDS.has(normalize(w.text)) || page.emphasis;
          const isActive = i === active;
          return (
            <React.Fragment key={`${page.id}-${i}`}>
              <span
                style={{
                  display: 'inline-block',
                  margin: '0 7px',
                  padding: isKey && !page.emphasis ? '0 12px' : 0,
                  borderRadius: 14,
                  background: isKey && !page.emphasis ? COLORS.yellow : 'transparent',
                  color: isKey && !page.emphasis ? COLORS.ink : isActive || page.emphasis ? COLORS.yellow : COLORS.white,
                  textShadow: isKey && !page.emphasis ? 'none' : outlineShadow(COLORS.ink, 3),
                  transform: isActive ? 'scale(1.07)' : 'scale(1)',
                }}
              >
                {show(w.text)}
              </span>
              {i === page.breakAfter ? <br /> : null}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
