import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';

export type CamState = {scale: number; x: number; y: number; rotate?: number};

type CameraProps = {
  /** Durasi beat/segmen (frame), dipakai untuk menyebar gerakan from -> to. */
  duration: number;
  from: CamState;
  to?: CamState;
  originX?: number;
  originY?: number;
  /** Amplitudo camera shake (px). 0 = tanpa shake. Deterministik (tanpa random). */
  shake?: number;
  shakeFrom?: number;
  shakeTo?: number;
  /** Jika diisi, gerakan from -> to selesai dalam sekian frame (mis. quick push-in). */
  easeFrames?: number;
  children: React.ReactNode;
};

export const Camera: React.FC<CameraProps> = ({
  duration,
  from,
  to = from,
  originX = 540,
  originY = 960,
  shake = 0,
  shakeFrom = 0,
  shakeTo = Number.POSITIVE_INFINITY,
  easeFrames,
  children,
}) => {
  const frame = useCurrentFrame();
  const end = Math.max(1, easeFrames ?? duration - 1);
  const t = interpolate(frame, [0, end], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.inOut(Easing.cubic),
  });
  const lerp = (a: number, b: number): number => a + (b - a) * t;

  const active = shake > 0 && frame >= shakeFrom && frame <= shakeTo;
  const sx = active ? Math.sin(frame * 2.1) * shake + Math.sin(frame * 4.3 + 1.3) * shake * 0.5 : 0;
  const sy = active ? Math.cos(frame * 2.7) * shake + Math.sin(frame * 5.1 + 0.4) * shake * 0.4 : 0;
  const rot =
    lerp(from.rotate ?? 0, to.rotate ?? 0) + (active ? Math.sin(frame * 1.7) * shake * 0.03 : 0);

  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        top: 0,
        width: 1080,
        height: 1920,
        transformOrigin: `${originX}px ${originY}px`,
        transform: `translate(${lerp(from.x, to.x) + sx}px, ${lerp(from.y, to.y) + sy}px) scale(${lerp(from.scale, to.scale)}) rotate(${rot}deg)`,
      }}
    >
      {children}
    </div>
  );
};
