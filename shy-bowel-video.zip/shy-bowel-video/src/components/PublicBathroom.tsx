import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS, FONT_FAMILY} from '../styles/theme';
import {BgSvg} from './HomeBathroom';
import {FLOOR_Y, LAYOUT} from '../data/layout';

export type PublicVariant = 'stall' | 'door' | 'sink';

type Props = {
  variant?: PublicVariant;
  /** Sudut gagang pintu (derajat) untuk efek "takut pintu kebuka". */
  handleAngle?: number;
  /** Tampilkan bayangan kaki orang di celah bawah pintu. */
  shadowFeet?: boolean;
};

/** Toilet umum: cahaya dingin, sedikit gelap, canggung. */
export const PublicBathroom: React.FC<Props> = ({variant = 'stall', handleAngle = 0, shadowFeet = false}) => {
  const frame = useCurrentFrame();
  const flicker = 0.88 + 0.12 * Math.sin(frame * 0.7) * Math.sin(frame * 0.11);
  const vLines: number[] = [];
  for (let x = -120; x <= 1200; x += 120) vLines.push(x);
  const hLines: number[] = [];
  for (let y = 0; y <= 1400; y += 120) hLines.push(y);

  const wall = (
    <>
      <rect x={-120} y={-120} width={1320} height={2160} fill="url(#pb-wall)" />
      {vLines.map((x) => (
        <line key={`v${x}`} x1={x} y1={-120} x2={x} y2={1400} stroke="#7F8896" strokeWidth={3} opacity={0.35} />
      ))}
      {hLines.map((y) => (
        <line key={`h${y}`} x1={-120} y1={y} x2={1200} y2={y} stroke="#7F8896" strokeWidth={3} opacity={0.35} />
      ))}
    </>
  );

  const defs = (
    <defs>
      <linearGradient id="pb-wall" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#8F99A8" />
        <stop offset="1" stopColor="#657080" />
      </linearGradient>
      <linearGradient id="pb-floor" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#59636F" />
        <stop offset="1" stopColor="#3C444E" />
      </linearGradient>
      <linearGradient id="pb-door" x1="0" y1="0" x2="1" y2="0">
        <stop offset="0" stopColor="#B4BCC8" />
        <stop offset="1" stopColor="#98A1AE" />
      </linearGradient>
      <radialGradient id="pb-vig" cx="0.5" cy="0.45" r="0.8">
        <stop offset="0.5" stopColor="#0B1220" stopOpacity="0" />
        <stop offset="1" stopColor="#0B1220" stopOpacity="0.45" />
      </radialGradient>
    </defs>
  );

  const light = (
    <g opacity={flicker}>
      <rect x={260} y={20} width={560} height={26} rx={12} fill="#EAF4FF" />
      <polygon points="290,46 790,46 980,520 100,520" fill="#DCEBFF" opacity={0.12} />
    </g>
  );

  if (variant === 'sink') {
    return (
      <BgSvg>
        {defs}
        {wall}
        <rect x={-120} y={1330} width={1320} height={710} fill="url(#pb-floor)" />
        {light}
        <rect x={190} y={250} width={700} height={540} rx={24} fill="#324050" />
        <rect x={206} y={266} width={668} height={508} rx={14} fill="#CFE2F0" />
        <polygon points="260,774 460,266 540,266 340,774" fill="#FFFFFF" opacity={0.35} />
        <rect x={150} y={880} width={780} height={60} rx={16} fill="#E4E8EE" stroke={COLORS.ink} strokeWidth={6} />
        <path d="M 230 940 L 850 940 L 800 1130 Q 790 1180 740 1180 L 340 1180 Q 290 1180 280 1130 Z" fill="#F4F6F9" stroke={COLORS.ink} strokeWidth={6} strokeLinejoin="round" />
        <rect x={510} y={780} width={60} height={110} rx={10} fill="#AEB8C4" stroke={COLORS.ink} strokeWidth={5} />
        <rect x={470} y={770} width={140} height={22} rx={10} fill="#AEB8C4" stroke={COLORS.ink} strokeWidth={5} />
        <rect x={720} y={800} width={60} height={80} rx={10} fill="#7FB0D8" stroke={COLORS.ink} strokeWidth={5} />
        <rect x={-120} y={-120} width={1320} height={2160} fill="url(#pb-vig)" />
      </BgSvg>
    );
  }

  if (variant === 'door') {
    const d = LAYOUT.b02.door;
    const p = LAYOUT.b02.plate;
    const slats: number[] = [];
    for (let y = d.y + 70; y < d.y + 230; y += 26) slats.push(y);
    const hx = d.x + d.w - 90;
    const hy = d.y + 540;
    const floorTop = d.y + d.h + 20;
    return (
      <BgSvg>
        {defs}
        {wall}
        <rect x={-120} y={floorTop} width={1320} height={2040 - floorTop} fill="url(#pb-floor)" />
        {light}
        {/* pintu tetangga (gelap) */}
        <rect x={d.x + d.w + 90} y={d.y} width={d.w} height={d.h} fill="#7C8593" stroke={COLORS.ink} strokeWidth={6} />
        {/* pintu utama */}
        <rect x={d.x} y={d.y} width={d.w} height={d.h} fill="url(#pb-door)" stroke={COLORS.ink} strokeWidth={8} />
        {slats.map((y) => (
          <line key={`s${y}`} x1={d.x + 50} y1={y} x2={d.x + d.w - 50} y2={y} stroke="#6F7886" strokeWidth={8} strokeLinecap="round" />
        ))}
        <rect x={d.x + 24} y={d.y + 24} width={d.w - 48} height={d.h - 48} fill="none" stroke="#8B94A2" strokeWidth={5} />
        {/* celah bawah pintu */}
        <rect x={d.x} y={d.y + d.h - 70} width={d.w} height={70} fill="#E8F0F8" opacity={0.9} />
        {shadowFeet ? (
          <g fill="#1A2030" opacity={0.85}>
            <ellipse cx={d.x + 190 + Math.sin(frame / 7) * 6} cy={d.y + d.h - 34} rx={46} ry={22} />
            <ellipse cx={d.x + 320 + Math.sin(frame / 7) * 6} cy={d.y + d.h - 34} rx={46} ry={22} />
          </g>
        ) : null}
        {/* papan TOILET UMUM */}
        <g transform={`rotate(-4 ${p.x + p.w / 2} ${p.y + p.h / 2})`}>
          <rect x={p.x} y={p.y} width={p.w} height={p.h} rx={10} fill="#F4F6F9" stroke={COLORS.ink} strokeWidth={6} />
          <text
            x={p.x + p.w / 2}
            y={p.y + 68}
            textAnchor="middle"
            fontFamily={FONT_FAMILY}
            fontWeight={900}
            fontSize={62}
            fill={COLORS.darkGray}
          >
            TOILET
          </text>
          <text
            x={p.x + p.w / 2}
            y={p.y + 134}
            textAnchor="middle"
            fontFamily={FONT_FAMILY}
            fontWeight={900}
            fontSize={62}
            fill={COLORS.darkGray}
          >
            UMUM
          </text>
        </g>
        {/* gagang */}
        <g transform={`rotate(${handleAngle} ${hx} ${hy})`}>
          <rect x={hx - 30} y={hy - 16} width={90} height={32} rx={16} fill="#C9D0DA" stroke={COLORS.ink} strokeWidth={5} />
          <circle cx={hx} cy={hy} r={26} fill="#AEB8C4" stroke={COLORS.ink} strokeWidth={5} />
        </g>
        <rect x={-120} y={-120} width={1320} height={2160} fill="url(#pb-vig)" />
      </BgSvg>
    );
  }

  // 'stall': bilik dari dalam (pintu tertutup di belakang karakter)
  return (
    <BgSvg>
      {defs}
      {wall}
      <rect x={-120} y={1240} width={1320} height={800} fill="url(#pb-floor)" />
      {light}
      <rect x={170} y={60} width={740} height={1180} fill="url(#pb-door)" stroke={COLORS.ink} strokeWidth={8} />
      <rect x={196} y={86} width={688} height={1128} fill="none" stroke="#8B94A2" strokeWidth={5} />
      <rect x={780} y={640} width={60} height={120} rx={12} fill="#7C8593" stroke={COLORS.ink} strokeWidth={5} />
      <circle cx={810} cy={700} r={14} fill="#C9D0DA" stroke={COLORS.ink} strokeWidth={4} />
      <path d="M 560 120 L 560 190 Q 560 210 580 210 L 600 210" fill="none" stroke="#6F7886" strokeWidth={10} strokeLinecap="round" />
      {/* celah bawah pintu */}
      <rect x={170} y={1180} width={740} height={60} fill="#E8F0F8" opacity={0.92} />
      {shadowFeet ? (
        <g fill="#1A2030" opacity={0.85}>
          <ellipse cx={400 + Math.sin(frame / 8) * 8} cy={1212} rx={46} ry={20} />
          <ellipse cx={520 + Math.sin(frame / 8) * 8} cy={1212} rx={46} ry={20} />
        </g>
      ) : null}
      {/* sekat kiri & kanan */}
      <polygon points="-120,-120 170,40 170,1240 -120,1420" fill="#7C8593" stroke={COLORS.ink} strokeWidth={8} />
      <polygon points="1200,-120 910,40 910,1240 1200,1420" fill="#6F7886" stroke={COLORS.ink} strokeWidth={8} />
      <line x1={-120} y1={FLOOR_Y + 120} x2={170} y2={1240} stroke="#5A6370" strokeWidth={6} />
      <rect x={-120} y={-120} width={1320} height={2160} fill="url(#pb-vig)" />
    </BgSvg>
  );
};
