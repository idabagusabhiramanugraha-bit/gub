import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS, FONT_FAMILY, outlineShadow} from '../styles/theme';
import type {Box} from '../data/layout';

/** Kilau 4 titik yang berkedip dan berputar pelan. */
export const Sparkle: React.FC<{x: number; y: number; size?: number; phase?: number; color?: string}> = ({
  x,
  y,
  size = 40,
  phase = 0,
  color = COLORS.yellow,
}) => {
  const frame = useCurrentFrame();
  const s = 0.55 + 0.45 * Math.abs(Math.sin((frame + phase) / 11));
  return (
    <svg
      width={size * 2}
      height={size * 2}
      viewBox="-1.2 -1.2 2.4 2.4"
      style={{position: 'absolute', left: x - size, top: y - size, overflow: 'visible'}}
    >
      <g transform={`rotate(${(frame + phase) * 1.5}) scale(${s})`}>
        <path
          d="M 0 -1 L 0.26 -0.26 L 1 0 L 0.26 0.26 L 0 1 L -0.26 0.26 L -1 0 L -0.26 -0.26 Z"
          fill={color}
          stroke={COLORS.ink}
          strokeWidth={0.07}
          strokeLinejoin="round"
        />
      </g>
    </svg>
  );
};

/** Tiga garis kuning miring (rasa kaget / nyaman / waspada). */
export const ComfortLines: React.FC<{x: number; y: number; size?: number; color?: string; rotate?: number}> = ({
  x,
  y,
  size = 90,
  color = COLORS.yellow,
  rotate = 0,
}) => {
  const frame = useCurrentFrame();
  const pulse = 1 + 0.08 * Math.sin(frame / 4);
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      style={{
        position: 'absolute',
        left: x,
        top: y,
        overflow: 'visible',
        transform: `rotate(${rotate}deg) scale(${pulse})`,
        transformOrigin: '50% 50%',
      }}
    >
      {[
        'M 10 62 L 34 54',
        'M 24 30 L 44 40',
        'M 52 8 L 58 32',
      ].map((d) => (
        <g key={d}>
          <path d={d} stroke={COLORS.ink} strokeWidth={16} strokeLinecap="round" />
          <path d={d} stroke={color} strokeWidth={9} strokeLinecap="round" />
        </g>
      ))}
    </svg>
  );
};

/** Garis getaran di kiri-kanan area karakter. */
export const ShakeLines: React.FC<{box: Box}> = ({box}) => {
  const frame = useCurrentFrame();
  const j = Math.sin(frame * 1.9) * 6;
  const left = box.x - 10;
  const right = box.x + box.w + 10;
  const ys = [0.18, 0.42, 0.66, 0.86].map((r) => box.y + box.h * r);
  const zig = (cx: number, cy: number, dir: number) =>
    `M ${cx} ${cy - 40} q ${dir * 18} 14 0 28 q ${dir * -18} 14 0 28 q ${dir * 18} 14 0 28`;
  return (
    <svg
      width={1080}
      height={1920}
      viewBox="0 0 1080 1920"
      style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}}
    >
      {ys.map((y, i) => (
        <g key={y}>
          <path d={zig(left + (i % 2 ? j : -j), y, -1)} stroke={COLORS.ink} strokeWidth={7} fill="none" strokeLinecap="round" />
          <path d={zig(right + (i % 2 ? -j : j), y, 1)} stroke={COLORS.ink} strokeWidth={7} fill="none" strokeLinecap="round" />
        </g>
      ))}
    </svg>
  );
};

/** Teks komik pop ("!?", "!!", "Hmph!") dengan spring dan goyang pelan. */
export const MarkBurst: React.FC<{
  box: Box;
  text: string;
  at: number;
  color?: string;
  fontSize?: number;
  rotate?: number;
}> = ({box, text, at, color = COLORS.red, fontSize, rotate = -8}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < at) {
    return null;
  }
  const s = spring({frame: frame - at, fps, config: {damping: 9, stiffness: 200, mass: 0.55}});
  const wob = Math.sin((frame - at) / 3) * 3;
  return (
    <div
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: FONT_FAMILY,
        fontWeight: 900,
        fontStyle: 'italic',
        fontSize: fontSize ?? box.h * 0.9,
        color,
        textShadow: outlineShadow(COLORS.ink, 5),
        transform: `scale(${0.2 + 0.8 * s}) rotate(${rotate + wob}deg)`,
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </div>
  );
};

/** Hati kecil melayang naik. */
export const FloatHeart: React.FC<{x: number; y: number; at: number; size?: number}> = ({x, y, at, size = 90}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < at) {
    return null;
  }
  const s = spring({frame: frame - at, fps, config: {damping: 8, stiffness: 160, mass: 0.6}});
  const rise = Math.min(40, (frame - at) * 1.2);
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      style={{
        position: 'absolute',
        left: x,
        top: y - rise,
        overflow: 'visible',
        transform: `scale(${s}) rotate(${12 + Math.sin(frame / 6) * 6}deg)`,
      }}
    >
      <path
        d="M 50 88 C 10 58 6 30 28 20 C 40 15 48 22 50 30 C 52 22 60 15 72 20 C 94 30 90 58 50 88 Z"
        fill={COLORS.red}
        stroke={COLORS.ink}
        strokeWidth={6}
        strokeLinejoin="round"
      />
    </svg>
  );
};

/** Ikon rumah kecil untuk "aman & nyaman". */
export const HouseIcon: React.FC<{box: Box; scale?: number}> = ({box, scale = 1}) => (
  <svg
    viewBox="0 0 120 120"
    style={{
      position: 'absolute',
      left: box.x,
      top: box.y,
      width: box.w,
      height: box.h,
      overflow: 'visible',
      transform: `scale(${scale})`,
      transformOrigin: '50% 60%',
    }}
  >
    <rect x={82} y={18} width={14} height={30} fill="#C98B5E" stroke={COLORS.ink} strokeWidth={5} />
    <rect x={20} y={54} width={80} height={56} rx={4} fill="#FFF3DA" stroke={COLORS.ink} strokeWidth={6} />
    <path d="M 8 58 L 60 12 L 112 58 Z" fill={COLORS.red} stroke={COLORS.ink} strokeWidth={6} strokeLinejoin="round" />
    <rect x={50} y={76} width={22} height={34} rx={3} fill="#8B5E3C" stroke={COLORS.ink} strokeWidth={5} />
    <rect x={28} y={68} width={16} height={16} fill={COLORS.yellow} stroke={COLORS.ink} strokeWidth={4} />
    <rect x={78} y={68} width={16} height={16} fill={COLORS.yellow} stroke={COLORS.ink} strokeWidth={4} />
  </svg>
);

/** Segitiga peringatan berkedip. */
export const WarningSign: React.FC<{box: Box; at: number}> = ({box, at}) => {
  const frame = useCurrentFrame();
  if (frame < at) {
    return null;
  }
  const on = (frame - at) % 14 < 9;
  return (
    <svg
      viewBox="0 0 100 100"
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        overflow: 'visible',
        opacity: on ? 1 : 0.35,
      }}
    >
      <path d="M 50 8 L 94 86 L 6 86 Z" fill={COLORS.yellow} stroke={COLORS.ink} strokeWidth={7} strokeLinejoin="round" />
      <path d="M 50 34 L 50 60" stroke={COLORS.ink} strokeWidth={9} strokeLinecap="round" />
      <circle cx={50} cy={74} r={5.5} fill={COLORS.ink} />
    </svg>
  );
};
