import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS} from '../styles/theme';
import type {Box} from '../data/layout';
import {Expression, Face} from './CharacterExpressions';

const INK = COLORS.ink;

export type ArmPose =
  | 'relax'
  | 'hips'
  | 'lap'
  | 'crossed'
  | 'chin'
  | 'chinHip'
  | 'fists'
  | 'point'
  | 'raise';

type Quad = [number, number, number, number]; // elbowX, elbowY, handX, handY
type ArmCoords = {l: Quad; r: Quad};

// Bahu kiri (125,300), bahu kanan (275,300) dalam koordinat karakter.
const SHOULDER_L = {x: 125, y: 300};
const SHOULDER_R = {x: 275, y: 300};

const ARMS: Record<ArmPose, ArmCoords> = {
  relax: {l: [88, 370, 100, 440], r: [312, 370, 300, 440]},
  hips: {l: [62, 365, 138, 408], r: [338, 365, 262, 408]},
  lap: {l: [92, 352, 160, 372], r: [308, 352, 240, 372]},
  crossed: {l: [120, 392, 252, 362], r: [280, 398, 150, 372]},
  chin: {l: [88, 370, 100, 440], r: [318, 345, 236, 268]},
  chinHip: {l: [62, 365, 138, 408], r: [318, 345, 236, 268]},
  fists: {l: [90, 345, 135, 318], r: [310, 345, 265, 318]},
  point: {l: [88, 370, 100, 440], r: [335, 318, 395, 285]},
  raise: {l: [88, 370, 100, 440], r: [330, 255, 338, 180]},
};

const mixQuad = (a: Quad, b: Quad, t: number): Quad => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
  a[3] + (b[3] - a[3]) * t,
];

const Arm: React.FC<{
  sx: number;
  sy: number;
  q: Quad;
  fist?: boolean;
  jx?: number;
  jy?: number;
}> = ({sx, sy, q, fist = false, jx = 0, jy = 0}) => {
  const [ex, ey, hx0, hy0] = q;
  const hx = hx0 + jx;
  const hy = hy0 + jy;
  const dx = ex - sx;
  const dy = ey - sy;
  const len = Math.hypot(dx, dy) || 1;
  const sleeve = 58;
  const px = sx + (dx / len) * sleeve;
  const py = sy + (dy / len) * sleeve;
  return (
    <g>
      <polyline
        points={`${sx},${sy} ${ex},${ey} ${hx},${hy}`}
        fill="none"
        stroke={INK}
        strokeWidth={13}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <line x1={sx} y1={sy} x2={px} y2={py} stroke={INK} strokeWidth={54} strokeLinecap="round" />
      <line x1={sx} y1={sy} x2={px} y2={py} stroke={COLORS.hoodie} strokeWidth={44} strokeLinecap="round" />
      <circle cx={hx} cy={hy} r={fist ? 20 : 17} fill={INK} />
    </g>
  );
};

const Legs: React.FC<{walk?: number}> = ({walk}) => {
  const p = (walk ?? 0) * 0.45;
  const active = walk !== undefined;
  const lx = 160 + (active ? Math.sin(p) * 34 : 0);
  const ly = 552 - (active ? Math.max(0, Math.cos(p)) * 18 : 0);
  const rx = 240 + (active ? Math.sin(p + Math.PI) * 34 : 0);
  const ry = 552 - (active ? Math.max(0, Math.cos(p + Math.PI)) * 18 : 0);
  return (
    <g>
      <ellipse cx={200} cy={566} rx={120} ry={14} fill="rgba(0,0,0,0.18)" />
      <line x1={170} y1={430} x2={lx} y2={ly} stroke={INK} strokeWidth={13} strokeLinecap="round" />
      <line x1={230} y1={430} x2={rx} y2={ry} stroke={INK} strokeWidth={13} strokeLinecap="round" />
      <ellipse cx={lx - 6} cy={ly + 6} rx={30} ry={13} fill={INK} />
      <ellipse cx={rx + 6} cy={ry + 6} rx={30} ry={13} fill={INK} />
    </g>
  );
};

const Drop: React.FC<{x: number; y: number; opacity: number}> = ({x, y, opacity}) => (
  <path
    d="M 0 -14 Q 10 3 0 9 Q -10 3 0 -14 Z"
    transform={`translate(${x} ${y})`}
    fill="#BFE3FF"
    stroke={INK}
    strokeWidth={3}
    opacity={opacity}
  />
);

export type CharacterArtProps = {
  expression: Expression;
  arms?: ArmPose;
  armsTo?: ArmPose;
  armsT?: number;
  legs?: boolean;
  walk?: number;
  faceShift?: number;
  look?: number;
  lookY?: number;
  tilt?: number;
  sweat?: boolean;
  blush?: boolean;
  tremble?: number;
  bob?: number;
  flip?: boolean;
  pointer?: boolean;
};

/** Karakter utama sebagai <g> SVG (koordinat 0..400, y -10..590). Satu desain untuk semua beat. */
export const CharacterArt: React.FC<CharacterArtProps> = ({
  expression,
  arms = 'relax',
  armsTo,
  armsT = 0,
  legs = true,
  walk,
  faceShift = 0,
  look = 0,
  lookY = 0,
  tilt = 0,
  sweat = false,
  blush = false,
  tremble = 0,
  bob = 0,
  flip = false,
  pointer = false,
}) => {
  const frame = useCurrentFrame();
  const blink = frame % 96 < 4;
  const jx = tremble ? Math.sin(frame * 2.7) * tremble : 0;
  const jy = tremble ? Math.cos(frame * 3.1) * tremble * 0.6 : 0;
  const bobY = bob ? Math.sin(frame / 14) * bob : 0;

  const base = ARMS[arms];
  const target = armsTo ? ARMS[armsTo] : base;
  const pose: ArmCoords = {
    l: mixQuad(base.l, target.l, armsT),
    r: mixQuad(base.r, target.r, armsT),
  };
  const fist = arms === 'fists' || armsTo === 'fists';

  const mirror = flip ? 'translate(400 0) scale(-1 1)' : '';
  const faceScale = 1 - Math.abs(faceShift) / 420;

  return (
    <g transform={`${mirror} translate(${jx} ${jy + bobY})`}>
      {legs ? <Legs walk={walk} /> : null}

      {/* hood (di belakang kepala) */}
      <path
        d="M 126 262 C 138 306 262 306 274 262 C 250 246 150 246 126 262 Z"
        fill={COLORS.hoodieShade}
        stroke={INK}
        strokeWidth={6}
        strokeLinejoin="round"
      />
      {/* badan hoodie */}
      <path
        d="M 135 270 C 110 285 100 340 108 430 L 292 430 C 300 340 290 285 265 270 Z"
        fill={COLORS.hoodie}
        stroke={INK}
        strokeWidth={6}
        strokeLinejoin="round"
      />
      <path d="M 262 300 C 280 340 284 390 280 428" fill="none" stroke={COLORS.hoodieShade} strokeWidth={10} strokeLinecap="round" />
      {/* tali */}
      <path d="M 182 284 L 178 346 M 218 284 L 222 346" stroke={INK} strokeWidth={10} strokeLinecap="round" fill="none" />
      <path d="M 182 284 L 178 346 M 218 284 L 222 346" stroke={COLORS.white} strokeWidth={5} strokeLinecap="round" fill="none" />
      {/* kantong */}
      <path
        d="M 150 380 L 250 380 L 262 428 L 138 428 Z"
        fill={COLORS.hoodie}
        stroke={INK}
        strokeWidth={4}
        strokeLinejoin="round"
      />

      {/* kepala + rambut + wajah */}
      <g transform={`rotate(${tilt} 200 200)`}>
        <circle cx={200} cy={170} r={95} fill={COLORS.white} stroke={INK} strokeWidth={7} />
        <path d="M 262 120 Q 292 170 262 232 Q 278 190 262 120 Z" fill="#DADFE8" />
        <g transform="translate(0 40)">
          <path
            d="M 108 112 C 100 85 108 60 126 48 L 118 14 L 150 36 L 158 -2 L 184 30 L 200 -16 L 218 28 L 246 -4 L 248 38 L 282 14 L 272 52 C 292 66 300 92 292 112 C 270 84 236 72 200 72 C 164 72 130 84 108 112 Z"
            fill={COLORS.hair}
            stroke={INK}
            strokeWidth={6}
            strokeLinejoin="round"
          />
          <path
            d="M 150 40 L 160 78 M 205 24 L 205 66 M 252 36 L 240 74 M 128 70 L 138 96 M 276 68 L 262 94"
            stroke={COLORS.hairLight}
            strokeWidth={5}
            strokeLinecap="round"
            fill="none"
          />
        </g>
        <g transform={`translate(${faceShift} 0) translate(200 0) scale(${faceScale} 1) translate(-200 0)`}>
          <Face expression={expression} look={look} lookY={lookY} blink={blink} blush={blush} />
        </g>
        {sweat ? (
          <>
            <Drop x={118} y={150 + ((frame * 2.4) % 34)} opacity={1 - ((frame * 2.4) % 34) / 40} />
            <Drop x={292} y={176 + ((frame * 2.4 + 14) % 34)} opacity={1 - ((frame * 2.4 + 14) % 34) / 40} />
            <Drop x={304} y={128 + ((frame * 2.4 + 24) % 34)} opacity={1 - ((frame * 2.4 + 24) % 34) / 40} />
          </>
        ) : null}
      </g>

      {/* lengan */}
      <Arm sx={SHOULDER_L.x} sy={SHOULDER_L.y} q={pose.l} fist={fist} jx={jx * 1.5} jy={jy * 1.5} />
      <Arm sx={SHOULDER_R.x} sy={SHOULDER_R.y} q={pose.r} fist={fist} jx={jx * 1.5} jy={jy * 1.5} />

      {pointer ? (
        <g>
          <line x1={395} y1={285} x2={432} y2={140} stroke={INK} strokeWidth={13} strokeLinecap="round" />
          <line x1={395} y1={285} x2={432} y2={140} stroke={COLORS.wood} strokeWidth={7} strokeLinecap="round" />
        </g>
      ) : null}
    </g>
  );
};

type MainCharacterProps = CharacterArtProps & {
  box: Box;
  view?: 'full' | 'bust';
};

const VIEWBOX = {
  full: '-40 -10 480 600',
  bust: '40 0 320 380',
} as const;

export const MainCharacter: React.FC<MainCharacterProps> = ({box, view = 'full', ...art}) => (
  <svg
    viewBox={VIEWBOX[view]}
    preserveAspectRatio="xMidYMid meet"
    style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, overflow: 'visible'}}
  >
    <CharacterArt {...art} />
  </svg>
);

type SeatedProps = CharacterArtProps & {
  box: Box;
  tone?: 'warm' | 'cool';
  paper?: boolean;
};

/** Karakter duduk di toilet: tangki + karakter + bowl dalam satu SVG supaya tidak pernah meleset. */
export const SeatedCharacter: React.FC<SeatedProps> = ({box, tone = 'warm', paper = true, ...art}) => {
  const fill = tone === 'warm' ? '#FFFFFF' : '#EEF1F6';
  const shade = tone === 'warm' ? '#EADFCB' : '#C7CEDA';
  return (
    <svg
      viewBox="-110 0 660 580"
      preserveAspectRatio="xMidYMid meet"
      style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, overflow: 'visible'}}
    >
      {/* tangki */}
      <rect x={-70} y={250} width={170} height={190} rx={22} fill={fill} stroke={INK} strokeWidth={6} />
      <rect x={-82} y={234} width={194} height={28} rx={12} fill={shade} stroke={INK} strokeWidth={6} />
      <circle cx={18} cy={222} r={10} fill={COLORS.gray} stroke={INK} strokeWidth={5} />

      {paper ? (
        <g>
          <rect x={462} y={296} width={14} height={96} rx={6} fill={COLORS.gray} stroke={INK} strokeWidth={4} />
          <ellipse cx={510} cy={340} rx={38} ry={42} fill={COLORS.white} stroke={INK} strokeWidth={5} />
          <ellipse cx={510} cy={340} rx={12} ry={14} fill={shade} stroke={INK} strokeWidth={4} />
          <path
            d="M 482 376 L 486 452 L 496 444 L 506 454 L 516 444 L 526 452 L 530 380 Z"
            fill={COLORS.white}
            stroke={INK}
            strokeWidth={4}
            strokeLinejoin="round"
          />
        </g>
      ) : null}

      <CharacterArt {...art} legs={false} />

      {/* bowl depan (menutup pinggang) */}
      <path
        d="M -30 392 Q -30 372 -6 372 L 406 372 Q 430 372 430 392 L 410 520 Q 404 566 350 566 L 50 566 Q -4 566 -10 520 Z"
        fill={fill}
        stroke={INK}
        strokeWidth={6}
        strokeLinejoin="round"
      />
      <path d="M -10 392 L 410 392" stroke={shade} strokeWidth={8} strokeLinecap="round" />
      <path d="M 30 530 Q 200 552 370 530" stroke={shade} strokeWidth={8} strokeLinecap="round" fill="none" />
    </svg>
  );
};
