import React from 'react';
import {useCurrentFrame} from 'remotion';
import {COLORS} from '../styles/theme';
import type {Box} from '../data/layout';
import {BgSvg, HomeBathroom} from './HomeBathroom';
import {PublicBathroom, PublicVariant} from './PublicBathroom';

type EnvProps =
  | {kind: 'home'; glow?: number}
  | {kind: 'public'; variant?: PublicVariant; handleAngle?: number; shadowFeet?: boolean};

/** Pembungkus: pilih lingkungan toilet rumah (hangat) atau toilet umum (dingin). */
export const ToiletEnvironment: React.FC<EnvProps> = (props) =>
  props.kind === 'home' ? (
    <HomeBathroom glow={props.glow} />
  ) : (
    <PublicBathroom variant={props.variant} handleAngle={props.handleAngle} shadowFeet={props.shadowFeet} />
  );

/** Background ilustratif untuk penjelasan psikologis (biru lembut, ada kedalaman). */
export const PsychBackground: React.FC<{warmAccent?: boolean}> = ({warmAccent = false}) => {
  const frame = useCurrentFrame();
  return (
    <BgSvg>
      <defs>
        <linearGradient id="ps-bg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#86A5D4" />
          <stop offset="1" stopColor="#35507F" />
        </linearGradient>
        <radialGradient id="ps-glow" cx="0.5" cy="0.42" r="0.6">
          <stop offset="0" stopColor="#FFFFFF" stopOpacity="0.32" />
          <stop offset="1" stopColor="#FFFFFF" stopOpacity="0" />
        </radialGradient>
        <pattern id="ps-dots" width="60" height="60" patternUnits="userSpaceOnUse">
          <circle cx="30" cy="30" r="3.5" fill="#FFFFFF" opacity="0.14" />
        </pattern>
      </defs>
      <rect x={-120} y={-120} width={1320} height={2160} fill="url(#ps-bg)" />
      <rect x={-120} y={-120} width={1320} height={2160} fill="url(#ps-dots)" />
      <rect x={-120} y={-120} width={1320} height={2160} fill="url(#ps-glow)" />
      <circle cx={120 + Math.sin(frame / 40) * 30} cy={420} r={220} fill="#FFFFFF" opacity={0.06} />
      <circle cx={960 + Math.cos(frame / 46) * 26} cy={1060} r={280} fill="#FFFFFF" opacity={0.07} />
      <circle cx={760} cy={200 + Math.sin(frame / 34) * 18} r={120} fill={warmAccent ? COLORS.yellow : '#FFFFFF'} opacity={warmAccent ? 0.16 : 0.06} />
      <path d="M -120 1500 Q 300 1380 700 1470 T 1200 1420 L 1200 2040 L -120 2040 Z" fill="#243A63" opacity={0.55} />
    </BgSvg>
  );
};

/** Bayangan orang di luar bilik (siluet gelap semi-transparan). */
export const Silhouette: React.FC<{box: Box; opacity?: number; dx?: number}> = ({box, opacity = 0.55, dx = 0}) => (
  <svg
    viewBox="0 0 300 980"
    preserveAspectRatio="xMidYMid meet"
    style={{position: 'absolute', left: box.x + dx, top: box.y, width: box.w, height: box.h, overflow: 'visible'}}
  >
    <g fill="#10141F" opacity={opacity}>
      <ellipse cx={150} cy={120} rx={80} ry={96} />
      <path d="M 40 260 C 40 220 90 212 150 212 C 210 212 260 220 260 260 L 290 520 L 252 540 L 236 380 L 232 980 L 164 980 L 150 600 L 136 980 L 68 980 L 64 380 L 48 540 L 10 520 Z" />
    </g>
  </svg>
);

/** Toilet berdiri (tampak samping) untuk beat 9. */
export const Toilet: React.FC<{box: Box; wobble?: number}> = ({box, wobble = 0}) => (
  <svg
    viewBox="0 0 360 520"
    preserveAspectRatio="xMidYMax meet"
    style={{
      position: 'absolute',
      left: box.x,
      top: box.y,
      width: box.w,
      height: box.h,
      overflow: 'visible',
      transformOrigin: '50% 100%',
      transform: `rotate(${wobble}deg)`,
    }}
  >
    <ellipse cx={170} cy={508} rx={150} ry={12} fill="rgba(0,0,0,0.2)" />
    {/* tangki */}
    <rect x={190} y={30} width={150} height={190} rx={18} fill="#F4F7FB" stroke={COLORS.ink} strokeWidth={6} />
    <rect x={180} y={14} width={170} height={28} rx={12} fill="#DDE3EC" stroke={COLORS.ink} strokeWidth={6} />
    <circle cx={265} cy={8} r={11} fill={COLORS.gray} stroke={COLORS.ink} strokeWidth={5} />
    {/* bowl */}
    <path
      d="M 14 250 Q 14 226 44 226 L 250 226 L 250 320 Q 250 400 190 424 L 214 486 L 64 486 L 82 430 Q 22 400 14 300 Z"
      fill="#F4F7FB"
      stroke={COLORS.ink}
      strokeWidth={6}
      strokeLinejoin="round"
    />
    {/* dudukan */}
    <ellipse cx={132} cy={232} rx={122} ry={32} fill="#FFFFFF" stroke={COLORS.ink} strokeWidth={6} />
    <ellipse cx={132} cy={236} rx={86} ry={19} fill="#9FCBE6" stroke={COLORS.ink} strokeWidth={4} />
    <path d="M 40 300 Q 60 380 110 410" stroke="#CBD3DF" strokeWidth={8} strokeLinecap="round" fill="none" />
    {/* tutup terangkat */}
    <path d="M 70 214 L 96 96 Q 100 80 118 82 L 200 90 L 190 224 Z" fill="#FFFFFF" stroke={COLORS.ink} strokeWidth={6} strokeLinejoin="round" />
  </svg>
);
