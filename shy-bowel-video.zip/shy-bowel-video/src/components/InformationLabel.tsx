import React from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {COLORS, FONT_FAMILY} from '../styles/theme';
import type {Box} from '../data/layout';

type Variant = 'red' | 'blue' | 'yellow' | 'bubble';

type Props = {
  text: string;
  box: Box;
  /** Frame (relatif ke beat) saat label muncul. Sebelum itu tidak dirender. */
  at: number;
  variant?: Variant;
  tilt?: number;
  fontSize?: number;
};

const STYLE: Record<Variant, {bg: string; fg: string; radius: number | string}> = {
  red: {bg: COLORS.red, fg: COLORS.white, radius: 26},
  blue: {bg: COLORS.blue, fg: COLORS.white, radius: 26},
  yellow: {bg: COLORS.yellow, fg: COLORS.ink, radius: 30},
  bubble: {bg: COLORS.yellow, fg: COLORS.ink, radius: '50%'},
};

/** Label informasi: hanya muncul saat dibutuhkan, pop-in dengan spring. */
export const InformationLabel: React.FC<Props> = ({text, box, at, variant = 'red', tilt = 0, fontSize = 46}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (frame < at) {
    return null;
  }
  const s = spring({frame: frame - at, fps, config: {damping: 11, stiffness: 190, mass: 0.6}});
  const st = STYLE[variant];
  return (
    <div
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        transform: `scale(${0.3 + 0.7 * s}) rotate(${tilt}deg)`,
        opacity: Math.min(1, s * 2),
        transformOrigin: '50% 50%',
      }}
    >
      <div
        style={{
          width: '100%',
          height: '100%',
          boxSizing: 'border-box',
          background: st.bg,
          color: st.fg,
          borderRadius: st.radius,
          border: `6px solid ${COLORS.ink}`,
          boxShadow: '0 10px 0 rgba(0,0,0,0.28)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          textAlign: 'center',
          padding: '0 18px',
          fontFamily: FONT_FAMILY,
          fontWeight: 900,
          fontSize,
          lineHeight: 1.1,
          letterSpacing: 0.5,
        }}
      >
        {text}
      </div>
      {variant === 'bubble' ? (
        <div
          style={{
            position: 'absolute',
            left: -34,
            bottom: 38,
            width: 0,
            height: 0,
            borderTop: '22px solid transparent',
            borderBottom: '22px solid transparent',
            borderRight: `46px solid ${COLORS.ink}`,
          }}
        />
      ) : null}
    </div>
  );
};
