import React from 'react';
import {COLORS} from '../styles/theme';

export type Expression =
  | 'smug'
  | 'flat'
  | 'suspicious'
  | 'grumpy'
  | 'tense'
  | 'thinking'
  | 'calm'
  | 'shocked'
  | 'serious'
  | 'proud';

const INK = COLORS.ink;

const line = (w = 6) => ({
  stroke: INK,
  strokeWidth: w,
  strokeLinecap: 'round' as const,
  strokeLinejoin: 'round' as const,
  fill: 'none',
});

// Posisi fitur wajah dalam koordinat karakter (kepala: pusat 200,170, r 95).
const EX = {l: 162, r: 238, y: 192};

type EyeProps = {
  cx: number;
  cy: number;
  left: boolean;
  ry?: number;
  rx?: number;
  slant?: number;
  look?: number;
  lookY?: number;
  lid?: boolean;
  pupil?: number;
};

const Eye: React.FC<EyeProps> = ({
  cx,
  cy,
  left,
  ry = 14,
  rx = 17,
  slant = 0,
  look = 0,
  lookY = 0,
  lid = false,
  pupil = 7,
}) => {
  const top = cy - ry;
  const y1 = left ? top - slant : top + slant;
  const y2 = left ? top + slant : top - slant;
  return (
    <g>
      <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={COLORS.white} stroke={INK} strokeWidth={5} />
      <circle cx={cx + look * 5} cy={cy + lookY * 3 + (lid ? 2 : 0)} r={pupil} fill={INK} />
      {lid ? (
        <line x1={cx - rx - 3} y1={y1} x2={cx + rx + 3} y2={y2} stroke={INK} strokeWidth={9} strokeLinecap="round" />
      ) : null}
    </g>
  );
};

type FaceProps = {
  expression: Expression;
  look?: number; // -1 kiri .. 1 kanan
  lookY?: number; // -1 atas .. 1 bawah
  blink?: boolean;
  blush?: boolean;
};

export const Face: React.FC<FaceProps> = ({expression, look = 0, lookY = 0, blink = false, blush = false}) => {
  const {l, r, y} = EX;

  const eyePair = (opts: {ry: number; slant?: number; lid?: boolean; rx?: number; pupil?: number}) =>
    blink ? (
      <>
        <path d={`M ${l - 16} ${y} L ${l + 16} ${y}`} {...line(6)} />
        <path d={`M ${r - 16} ${y} L ${r + 16} ${y}`} {...line(6)} />
      </>
    ) : (
      <>
        <Eye cx={l} cy={y} left {...opts} look={look} lookY={lookY} />
        <Eye cx={r} cy={y} left={false} {...opts} look={look} lookY={lookY} />
      </>
    );

  const cheeks = blush || expression === 'tense';

  let content: React.ReactNode;
  switch (expression) {
    case 'smug':
      content = (
        <>
          {eyePair({ry: 10, lid: true})}
          <path d={`M 140 164 Q 162 154 186 164`} {...line(6)} />
          <path d={`M 214 164 Q 238 154 262 164`} {...line(6)} />
          <path d={`M 166 234 Q 204 262 248 228`} {...line(6)} />
          <path d={`M 248 228 L 257 221`} {...line(5)} />
        </>
      );
      break;
    case 'flat':
      content = (
        <>
          {eyePair({ry: 10, lid: true})}
          <path d={`M 142 168 L 184 168`} {...line(6)} />
          <path d={`M 216 168 L 258 168`} {...line(6)} />
          <path d={`M 176 242 L 226 242`} {...line(6)} />
        </>
      );
      break;
    case 'suspicious':
      content = (
        <>
          {eyePair({ry: 9, slant: 5, lid: true})}
          <path d={`M 140 160 L 186 172`} {...line(6)} />
          <path d={`M 260 160 L 214 172`} {...line(6)} />
          <path d={`M 180 242 Q 205 236 228 244`} {...line(6)} />
        </>
      );
      break;
    case 'grumpy':
      content = (
        <>
          {eyePair({ry: 8, slant: 8, lid: true})}
          <path d={`M 138 154 L 188 176`} {...line(8)} />
          <path d={`M 262 154 L 212 176`} {...line(8)} />
          <path d={`M 172 250 Q 202 232 232 250`} {...line(6)} />
        </>
      );
      break;
    case 'tense':
      content = (
        <>
          <path d={`M 142 176 L 182 192 L 144 208`} {...line(7)} />
          <path d={`M 258 176 L 218 192 L 256 208`} {...line(7)} />
          <path d={`M 134 158 L 186 172`} {...line(8)} />
          <path d={`M 266 158 L 214 172`} {...line(8)} />
          <rect x={164} y={224} width={72} height={34} rx={10} fill={COLORS.white} stroke={INK} strokeWidth={5} />
          <path d={`M 182 224 L 182 258 M 200 224 L 200 258 M 218 224 L 218 258 M 164 241 L 236 241`} {...line(3)} />
        </>
      );
      break;
    case 'thinking':
      content = (
        <>
          {eyePair({ry: 13, slant: 1})}
          <path d={`M 140 162 Q 162 152 186 162`} {...line(6)} />
          <path d={`M 214 148 Q 240 134 264 148`} {...line(6)} />
          <path d={`M 180 242 Q 204 236 226 246`} {...line(6)} />
        </>
      );
      break;
    case 'calm':
      content = (
        <>
          <path d={`M 145 190 Q 162 206 180 190`} {...line(6)} />
          <path d={`M 220 190 Q 238 206 256 190`} {...line(6)} />
          <path d={`M 142 166 Q 162 158 184 166`} {...line(5)} />
          <path d={`M 216 166 Q 238 158 258 166`} {...line(5)} />
          <path d={`M 178 236 Q 200 250 224 236`} {...line(6)} />
        </>
      );
      break;
    case 'shocked':
      content = (
        <>
          {eyePair({ry: 22, rx: 22, pupil: 5})}
          <path d={`M 138 148 Q 160 132 184 148`} {...line(6)} />
          <path d={`M 216 148 Q 240 132 262 148`} {...line(6)} />
          <path
            d={`M 188 236 Q 206 224 224 238 Q 218 262 198 256 Q 186 250 188 236 Z`}
            fill="#8B2E2E"
            stroke={INK}
            strokeWidth={5}
            strokeLinejoin="round"
          />
        </>
      );
      break;
    case 'serious':
      content = (
        <>
          {eyePair({ry: 13, slant: 2, lid: true})}
          <path d={`M 142 162 L 186 168`} {...line(6)} />
          <path d={`M 258 162 L 214 168`} {...line(6)} />
          <path d={`M 182 242 L 220 240`} {...line(6)} />
        </>
      );
      break;
    case 'proud':
    default:
      content = (
        <>
          <path d={`M 145 198 Q 162 178 180 198`} {...line(6)} />
          <path d={`M 220 198 Q 238 178 256 198`} {...line(6)} />
          <path d={`M 140 160 Q 162 148 186 160`} {...line(5)} />
          <path d={`M 214 160 Q 238 148 260 160`} {...line(5)} />
          <path d={`M 166 230 Q 206 266 248 226`} {...line(6)} />
        </>
      );
  }

  return (
    <g>
      {cheeks ? (
        <>
          <ellipse cx={140} cy={224} rx={16} ry={9} fill={COLORS.red} opacity={0.3} />
          <ellipse cx={260} cy={224} rx={16} ry={9} fill={COLORS.red} opacity={0.3} />
        </>
      ) : null}
      {content}
    </g>
  );
};
