import React from 'react';
import {COLORS} from '../styles/theme';
import type {Box} from '../data/layout';

type Props = {box: Box; scale?: number; opacity?: number};

/** Sistem pencernaan versi sederhana (usus besar + usus halus), merah muda. */
export const DigestiveSystem: React.FC<Props> = ({box, scale = 1, opacity = 1}) => {
  const colon =
    'M 60 400 L 60 90 Q 60 40 110 40 L 190 40 Q 240 40 240 90 L 240 300 Q 240 340 205 340 L 175 340';
  const small = 'M 110 120 Q 150 100 190 120 T 190 170 T 110 170 T 110 220 T 190 220 T 190 270 T 120 270';
  return (
    <svg
      viewBox="0 0 300 440"
      preserveAspectRatio="xMidYMid meet"
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        overflow: 'visible',
        opacity,
        transformOrigin: '50% 50%',
        transform: `scale(${scale})`,
      }}
    >
      <path d={colon} fill="none" stroke={COLORS.ink} strokeWidth={58} strokeLinecap="round" strokeLinejoin="round" />
      <path d={colon} fill="none" stroke={COLORS.pink} strokeWidth={46} strokeLinecap="round" strokeLinejoin="round" />
      <path d={colon} fill="none" stroke={COLORS.pinkDark} strokeWidth={40} strokeLinecap="butt" strokeDasharray="4 24" opacity={0.7} />
      <path d={small} fill="none" stroke={COLORS.ink} strokeWidth={26} strokeLinecap="round" strokeLinejoin="round" />
      <path d={small} fill="none" stroke="#F8BFC6" strokeWidth={16} strokeLinecap="round" strokeLinejoin="round" />
      <path d="M 175 340 L 175 410" stroke={COLORS.ink} strokeWidth={34} strokeLinecap="round" />
      <path d="M 175 340 L 175 410" stroke={COLORS.pinkDark} strokeWidth={22} strokeLinecap="round" />
    </svg>
  );
};
