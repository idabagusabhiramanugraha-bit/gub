import React from 'react';
import {useCurrentFrame} from 'remotion';
import {FLOOR_Y} from '../data/layout';

/** SVG background yang lebih besar dari kanvas (overscan 120 px) supaya aman untuk gerakan kamera. */
export const BgSvg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg
    width={1320}
    height={2160}
    viewBox="-120 -120 1320 2160"
    style={{position: 'absolute', left: -120, top: -120}}
  >
    {children}
  </svg>
);

/** Toilet rumah: bersih, hangat, tenang. */
export const HomeBathroom: React.FC<{glow?: number}> = ({glow = 0.6}) => {
  const frame = useCurrentFrame();
  const vLines: number[] = [];
  for (let x = -120; x <= 1200; x += 120) vLines.push(x);
  const hLines: number[] = [];
  for (let y = 0; y <= FLOOR_Y; y += 120) hLines.push(y);
  const floorRadials: number[] = [];
  for (let x = -1400; x <= 2400; x += 260) floorRadials.push(x);

  return (
    <BgSvg>
      <defs>
        <linearGradient id="hb-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FAEED6" />
          <stop offset="1" stopColor="#EBD3A9" />
        </linearGradient>
        <linearGradient id="hb-floor" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#D9BC90" />
          <stop offset="1" stopColor="#B99567" />
        </linearGradient>
        <linearGradient id="hb-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#FFF7DA" />
          <stop offset="1" stopColor="#CBE6FA" />
        </linearGradient>
        <radialGradient id="hb-vig" cx="0.5" cy="0.45" r="0.75">
          <stop offset="0.6" stopColor="#7A4A10" stopOpacity="0" />
          <stop offset="1" stopColor="#7A4A10" stopOpacity="0.22" />
        </radialGradient>
      </defs>

      <rect x={-120} y={-120} width={1320} height={FLOOR_Y + 120} fill="url(#hb-wall)" />
      {vLines.map((x) => (
        <line key={`v${x}`} x1={x} y1={-120} x2={x} y2={FLOOR_Y} stroke="#C9A46F" strokeWidth={3} opacity={0.25} />
      ))}
      {hLines.map((y) => (
        <line key={`h${y}`} x1={-120} y1={y} x2={1200} y2={y} stroke="#C9A46F" strokeWidth={3} opacity={0.25} />
      ))}

      {/* lantai */}
      <rect x={-120} y={FLOOR_Y} width={1320} height={1040} fill="url(#hb-floor)" />
      {floorRadials.map((x) => (
        <line
          key={`r${x}`}
          x1={540 + (x - 540) * 0.2}
          y1={FLOOR_Y}
          x2={x}
          y2={2040}
          stroke="#A27E52"
          strokeWidth={3}
          opacity={0.35}
        />
      ))}
      {[1190, 1290, 1420, 1590, 1800].map((y) => (
        <line key={`fl${y}`} x1={-120} y1={y} x2={1200} y2={y} stroke="#A27E52" strokeWidth={3} opacity={0.35} />
      ))}
      <rect x={-120} y={FLOOR_Y - 26} width={1320} height={26} fill="#CDAE82" />
      <rect x={-120} y={FLOOR_Y - 30} width={1320} height={6} fill="#E7D2AD" />

      {/* jendela + berkas cahaya */}
      <polygon
        points="690,640 960,640 1180,1480 520,1480"
        fill="#FFF1B8"
        opacity={glow * 0.28}
      />
      <rect x={684} y={234} width={282} height={412} rx={10} fill="#8B6B4A" />
      <rect x={698} y={248} width={254} height={384} rx={4} fill="url(#hb-sky)" />
      <line x1={825} y1={248} x2={825} y2={632} stroke="#8B6B4A" strokeWidth={10} />
      <line x1={698} y1={440} x2={952} y2={440} stroke="#8B6B4A" strokeWidth={10} />
      <rect x={670} y={640} width={310} height={22} rx={6} fill="#A98458" />

      {/* handuk + rak */}
      <line x1={30} y1={396} x2={270} y2={396} stroke="#8B6B4A" strokeWidth={10} strokeLinecap="round" />
      <rect x={60} y={400} width={150} height={320} rx={10} fill="#F2C4B8" stroke="#C99484" strokeWidth={4} />
      <rect x={60} y={560} width={150} height={26} fill="#E9A99A" />
      <rect x={60} y={640} width={150} height={26} fill="#E9A99A" />
      {/* tanaman kecil */}
      <rect x={860} y={880} width={90} height={80} rx={14} fill="#C98B5E" stroke="#8B5E3C" strokeWidth={4} />
      <path d="M 905 880 C 880 820 850 800 840 760 M 905 880 C 910 810 940 790 950 740 M 905 880 C 930 840 980 830 990 800" stroke="#5F8F4E" strokeWidth={10} strokeLinecap="round" fill="none" />
      <rect x={868} y={960} width={74} height={160} fill="#B58B5C" />

      {/* karpet */}
      <ellipse cx={540} cy={1560} rx={440} ry={90} fill="#C99A6B" opacity={0.75} />
      <ellipse cx={540} cy={1560} rx={380} ry={66} fill="none" stroke="#E8C79A" strokeWidth={6} opacity={0.8} />

      {/* debu cahaya (deterministik) */}
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <circle
          key={`d${i}`}
          cx={760 + i * 48 + Math.sin(frame / 20 + i) * 10}
          cy={760 + i * 90 + Math.cos(frame / 24 + i * 2) * 12}
          r={4 + (i % 3)}
          fill="#FFFFFF"
          opacity={0.35 * glow}
        />
      ))}
      <rect x={-120} y={-120} width={1320} height={2160} fill="url(#hb-vig)" />
    </BgSvg>
  );
};
