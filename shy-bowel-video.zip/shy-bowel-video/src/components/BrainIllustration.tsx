import React from 'react';
import {COLORS} from '../styles/theme';
import type {Box} from '../data/layout';

type Props = {box: Box; scale?: number; rotate?: number; opacity?: number};

/** Otak merah muda sederhana (bukan ilustrasi medis). */
export const BrainIllustration: React.FC<Props> = ({box, scale = 1, rotate = 0, opacity = 1}) => (
  <svg
    viewBox="0 0 360 290"
    preserveAspectRatio="xMidYMid meet"
    style={{
      position: 'absolute',
      left: box.x,
      top: box.y,
      width: box.w,
      height: box.h,
      overflow: 'visible',
      opacity,
      transformOrigin: '50% 80%',
      transform: `scale(${scale}) rotate(${rotate}deg)`,
    }}
  >
    <path
      d="M 175 235 C 175 255 180 272 190 282 L 212 282 C 206 264 206 250 212 232 Z"
      fill="#E58C9C"
      stroke={COLORS.ink}
      strokeWidth={6}
      strokeLinejoin="round"
    />
    <path
      d="M 60 150 C 20 120 30 60 90 50 C 110 15 170 10 195 40 C 230 15 290 25 300 70 C 345 85 350 140 310 165 C 320 205 270 230 235 215 C 215 240 160 240 140 215 C 100 235 45 205 60 150 Z"
      fill={COLORS.pink}
      stroke={COLORS.ink}
      strokeWidth={7}
      strokeLinejoin="round"
    />
    <g stroke={COLORS.pinkDark} strokeWidth={6} strokeLinecap="round" fill="none">
      <path d="M 120 70 C 140 100 110 120 140 150" />
      <path d="M 200 45 C 190 80 215 100 200 135" />
      <path d="M 260 75 C 240 100 275 125 255 160" />
      <path d="M 90 150 C 120 140 130 175 160 170" />
      <path d="M 230 190 C 250 170 280 185 290 160" />
      <path d="M 170 205 C 185 180 205 195 215 175" />
    </g>
    <path d="M 100 84 Q 130 56 164 62" stroke={COLORS.pinkLight} strokeWidth={9} strokeLinecap="round" fill="none" opacity={0.85} />
  </svg>
);
