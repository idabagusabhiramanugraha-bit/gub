import React from 'react';
import {COLORS} from '../styles/theme';
import type {Box} from '../data/layout';

type Props = {
  box: Box;
  /** 0 = rileks, 1 = menegang. */
  tension: number;
};

/** Inset sederhana: saluran bawah dan otot yang menyempit saat tegang (bukan ilustrasi medis). */
export const PelvicMuscleIllustration: React.FC<Props> = ({box, tension}) => {
  const hw = 46 - 30 * tension;
  const pipe = `M 150 0 L 150 190 Q 150 250 ${200 - hw} 262 Q 150 276 150 340 L 150 400 L 250 400 L 250 340 Q 250 276 ${200 + hw} 262 Q 250 250 250 190 L 250 0 Z`;
  const squeeze = tension * 18;
  return (
    <svg
      viewBox="0 0 400 400"
      preserveAspectRatio="xMidYMid slice"
      style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h}}
    >
      <rect width={400} height={400} fill="#FFF3F0" />
      <path d={pipe} fill={COLORS.pink} stroke={COLORS.ink} strokeWidth={7} strokeLinejoin="round" />
      <path d={`M 168 20 L 168 180`} stroke={COLORS.pinkLight} strokeWidth={10} strokeLinecap="round" />
      <ellipse cx={200 - hw - 30 + squeeze} cy={262} rx={34} ry={56} fill={COLORS.red} stroke={COLORS.ink} strokeWidth={6} />
      <ellipse cx={200 + hw + 30 - squeeze} cy={262} rx={34} ry={56} fill={COLORS.red} stroke={COLORS.ink} strokeWidth={6} />
      <g stroke={COLORS.red} strokeWidth={9} strokeLinecap="round" fill="none" opacity={0.4 + 0.6 * tension}>
        <path d={`M ${60 + squeeze} 262 L ${96 + squeeze} 262 M ${84 + squeeze} 248 L ${98 + squeeze} 262 L ${84 + squeeze} 276`} />
        <path d={`M ${340 - squeeze} 262 L ${304 - squeeze} 262 M ${316 - squeeze} 248 L ${302 - squeeze} 262 L ${316 - squeeze} 276`} />
      </g>
    </svg>
  );
};
