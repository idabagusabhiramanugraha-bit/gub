import React from 'react';
import {Audio, Sequence, staticFile} from 'remotion';
import {BEAT_TIMING} from '../data/beats';
import {ENABLE_SFX} from '../data/config';
import {SFX_CUES} from '../data/sfx';

/** Semua sound effect (selain narasi). Dimatikan lewat ENABLE_SFX di data/config.ts. */
export const SoundEffects: React.FC = () => {
  if (!ENABLE_SFX) {
    return null;
  }
  return (
    <>
      {SFX_CUES.map((cue, i) => {
        const beat = BEAT_TIMING.find((b) => b.id === cue.beat);
        if (!beat || cue.at >= beat.duration) {
          return null;
        }
        return (
          <Sequence
            key={`${cue.beat}-${cue.file}-${cue.at}-${i}`}
            from={beat.from + cue.at}
            durationInFrames={cue.frames ?? 45}
            name={`sfx ${cue.file}`}
          >
            <Audio src={staticFile(`sounds/${cue.file}`)} volume={cue.volume} />
          </Sequence>
        );
      })}
    </>
  );
};
