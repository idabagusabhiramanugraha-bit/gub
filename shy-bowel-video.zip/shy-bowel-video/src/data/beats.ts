import {FPS, TOTAL_FRAMES, toFrame} from './config';

// Batas beat = ESTIMASI dari SRT per kalimat (proporsional jumlah karakter).
// Cek lagi setelah narasi.mp3 asli dipasang. Urutan 12 beat tetap.

export type BeatDef = {
  id: number;
  key: string;
  title: string; // hanya untuk perencanaan, TIDAK ditampilkan di video
  startSec: number;
  narration: string;
  transitionOut: string;
};

export const BEATS: BeatDef[] = [
  {id: 1, key: 'hook', title: 'Hook', startSec: 0, narration: 'Sepertinya pantat manusia punya standar keamanan sendiri. Di rumah langsung lancar...', transitionOut: 'hard cut + whoosh'},
  {id: 2, key: 'kontras', title: 'Kontras toilet umum', startSec: 5.2, narration: '...tapi di toilet umum malah mogok kerja!', transitionOut: 'impact cut + shake'},
  {id: 3, key: 'kebelet', title: 'Sudah kebelet', startSec: 8.3, narration: 'Pernah enggak sih, pas di rumah udah kebelet banget...', transitionOut: 'match cut'},
  {id: 4, key: 'nggak-bisa', title: 'Tiba-tiba nggak bisa', startSec: 11.2, narration: '...begitu sampai toilet umum, malah enggak bisa keluar.', transitionOut: 'quick push-in'},
  {id: 5, key: 'otak', title: 'Otak mulai waspada', startSec: 20.9, narration: 'Ternyata, ini ada hubungannya sama otak kita.', transitionOut: 'whip pan'},
  {id: 6, key: 'rumah', title: 'Kalau di rumah lebih nyaman', startSec: 24.7, narration: 'Saat di rumah, kita merasa aman dan nyaman...', transitionOut: 'warm-to-cold cut'},
  {id: 7, key: 'gangguan', title: 'Gangguan di toilet umum', startSec: 32.6, narration: 'Ada suara orang lewat, takut pintunya kebuka, ada yang nungguin.', transitionOut: 'impact zoom'},
  {id: 8, key: 'otot', title: 'Otak dan otot menegang', startSec: 40.3, narration: 'Otak langsung masuk mode waspada, dan otot... ikut tegang.', transitionOut: 'pull-out'},
  {id: 9, key: 'punchline-1', title: 'Punchline pertama', startSec: 45.2, narration: 'Lucunya, kita bukan enggak bisa berak...', transitionOut: 'cut saat narasi lanjut'},
  {id: 10, key: 'punchline-2', title: 'Punchline utama', startSec: 48.4, narration: '...kita cuma enggak percaya sama toilet yang sedang kita duduki!', transitionOut: 'smash cut'},
  {id: 11, key: 'fenomena', title: 'Penjelasan fenomena', startSec: 52.0, narration: 'Fenomena ini dikenal sebagai shy bowel syndrome.', transitionOut: 'circle wipe'},
  {id: 12, key: 'closing', title: 'Closing', startSec: 55.0, narration: 'Jadi, ternyata buat bisa berak dengan lancar... Pantat juga butuh privasi, guys!', transitionOut: 'freeze frame'},
];

export type BeatTiming = BeatDef & {from: number; duration: number};

export const BEAT_TIMING: BeatTiming[] = BEATS.map((beat, i) => {
  const from = i === 0 ? 0 : toFrame(beat.startSec);
  const nextBeat = BEATS[i + 1];
  const end = nextBeat ? toFrame(nextBeat.startSec) : TOTAL_FRAMES;
  return {...beat, from, duration: end - from};
});

/** Detik -> frame relatif terhadap awal beat tertentu (helper untuk menaruh aksi pada kata tertentu). */
export const secToBeatFrame = (beatId: number, seconds: number): number => {
  const beat = BEAT_TIMING.find((b) => b.id === beatId);
  return Math.round(seconds * FPS) - (beat?.from ?? 0);
};
