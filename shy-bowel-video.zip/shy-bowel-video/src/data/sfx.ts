// Sound effect per beat. Frame bersifat RELATIF terhadap awal beat.
// File di public/sounds/ adalah PLACEHOLDER sintetis (tools/make-placeholder-sounds.sh). Ganti dengan SFX asli
// dengan nama file yang sama, tanpa mengubah kode.

export type SfxCue = {
  beat: number;
  at: number;
  file: string;
  volume: number;
  frames?: number;
};

export const SFX_CUES: SfxCue[] = [
  {beat: 1, at: 6, file: 'ding.wav', volume: 0.5},

  {beat: 2, at: 0, file: 'whoosh.wav', volume: 0.5},
  {beat: 2, at: 8, file: 'step.wav', volume: 0.5},
  {beat: 2, at: 18, file: 'step.wav', volume: 0.5},
  {beat: 2, at: 28, file: 'step.wav', volume: 0.5},
  {beat: 2, at: 38, file: 'step.wav', volume: 0.5},
  {beat: 2, at: 48, file: 'scratch.wav', volume: 0.45},
  {beat: 2, at: 52, file: 'pop.wav', volume: 0.6},

  {beat: 3, at: 4, file: 'zap.wav', volume: 0.3},
  {beat: 3, at: 24, file: 'drip.wav', volume: 0.5},
  {beat: 3, at: 60, file: 'drip.wav', volume: 0.5},

  {beat: 4, at: 50, file: 'pop.wav', volume: 0.5},
  {beat: 4, at: 80, file: 'sigh.wav', volume: 0.5},
  {beat: 4, at: 117, file: 'zap.wav', volume: 0.35},
  {beat: 4, at: 150, file: 'drip.wav', volume: 0.5},

  {beat: 5, at: 0, file: 'whoosh.wav', volume: 0.5},
  {beat: 5, at: 14, file: 'pop.wav', volume: 0.6},
  {beat: 5, at: 30, file: 'beep.wav', volume: 0.45},

  {beat: 6, at: 6, file: 'sigh.wav', volume: 0.45},
  {beat: 6, at: 40, file: 'ting.wav', volume: 0.5},
  {beat: 6, at: 60, file: 'pop.wav', volume: 0.5},

  {beat: 7, at: 66, file: 'step.wav', volume: 0.5},
  {beat: 7, at: 76, file: 'step.wav', volume: 0.5},
  {beat: 7, at: 70, file: 'pop.wav', volume: 0.5},
  {beat: 7, at: 110, file: 'knock.wav', volume: 0.55},
  {beat: 7, at: 116, file: 'pop.wav', volume: 0.5},
  {beat: 7, at: 150, file: 'zap.wav', volume: 0.4},
  {beat: 7, at: 156, file: 'pop.wav', volume: 0.5},

  {beat: 8, at: 22, file: 'zap.wav', volume: 0.5},
  {beat: 8, at: 88, file: 'pop.wav', volume: 0.6},

  {beat: 9, at: 10, file: 'boing.wav', volume: 0.5},

  {beat: 10, at: 40, file: 'boing.wav', volume: 0.5},
  {beat: 10, at: 62, file: 'heart.wav', volume: 0.55},

  {beat: 11, at: 6, file: 'pop.wav', volume: 0.6},
  {beat: 11, at: 20, file: 'ting.wav', volume: 0.5},

  {beat: 12, at: 2, file: 'ding.wav', volume: 0.4},
  {beat: 12, at: 183, file: 'ding.wav', volume: 0.55},
];
