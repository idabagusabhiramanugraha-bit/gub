// Koordinat eksplisit untuk kanvas 1080 x 1920. Ini sumber kebenaran layout.
// Tidak ada header: area atas selalu bagian dari background adegan.

export type Box = {x: number; y: number; w: number; h: number};

export const CANVAS = {width: 1080, height: 1920} as const;
export const BACKGROUND: Box = {x: 0, y: 0, w: 1080, h: 1920};

/** Subtitle: bawah-aman untuk UI Shorts/Reels/TikTok (sisa 310 px di bawah, 120 px di kanan). */
export const SUBTITLE: Box = {x: 60, y: 1400, w: 900, h: 210};
export const SAFE: Box = {x: 60, y: 200, w: 900, h: 1420};

/** Garis lantai untuk background rumah/umum. */
export const FLOOR_Y = 1120;

export const LAYOUT = {
  b01: {
    character: {x: 200, y: 480, w: 680, h: 840},
    sparkle: {x: 760, y: 520, w: 160, h: 160},
  },
  b02: {
    character: {x: 420, y: 640, w: 600, h: 720},
    door: {x: 90, y: 300, w: 520, h: 1000},
    plate: {x: 150, y: 520, w: 320, h: 160},
    mark: {x: 740, y: 380, w: 180, h: 180},
  },
  b03: {
    character: {x: 220, y: 560, w: 640, h: 760},
    shake: {x: 160, y: 520, w: 760, h: 820},
  },
  b04: {
    character: {x: 200, y: 540, w: 640, h: 760},
    silhouette: {x: 760, y: 360, w: 300, h: 980},
    mark: {x: 760, y: 420, w: 150, h: 150},
  },
  b05: {
    character: {x: 120, y: 700, w: 600, h: 660},
    brain: {x: 140, y: 320, w: 560, h: 420},
    bubble: {x: 640, y: 820, w: 380, h: 260},
    warn: {x: 80, y: 480, w: 140, h: 140},
  },
  b06: {
    character: {x: 140, y: 640, w: 620, h: 700},
    house: {x: 700, y: 260, w: 220, h: 220},
    label: {x: 600, y: 520, w: 400, h: 180},
    digestive: {x: 640, y: 760, w: 300, h: 420},
  },
  b07: {
    character: {x: 100, y: 620, w: 540, h: 700},
    label1: {x: 640, y: 300, w: 340, h: 140},
    label2: {x: 640, y: 480, w: 340, h: 140},
    label3: {x: 640, y: 660, w: 340, h: 140},
  },
  b08: {
    body: {x: 120, y: 380, w: 480, h: 900},
    inset: {x: 560, y: 780, w: 420, h: 420},
    label: {x: 640, y: 320, w: 340, h: 200},
  },
  b09: {
    character: {x: 80, y: 620, w: 560, h: 720},
    toilet: {x: 600, y: 700, w: 400, h: 640},
    hmph: {x: 620, y: 420, w: 260, h: 110},
  },
  b10: {
    character: {x: 120, y: 600, w: 560, h: 740},
    heart: {x: 700, y: 500, w: 100, h: 100},
  },
  b11: {
    character: {x: 560, y: 820, w: 440, h: 540},
    title: {x: 90, y: 300, w: 900, h: 420},
  },
  b12: {
    character: {x: 160, y: 560, w: 620, h: 780},
    sparkle: {x: 700, y: 560, w: 200, h: 200},
  },
} as const;
