import {toFrame} from './config';

// Sumber caption = SRT yang diberikan. File captions.srt di root proyek berisi isi yang sama.
// SRT hanya punya timestamp per kalimat, jadi waktu tiap kata DIPERKIRAKAN secara proporsional
// berdasarkan jumlah karakter (+ jeda kecil di tanda baca). Sinkronisasi per kata belum final.

export const SRT_SOURCE = `1
00:00:00,100 --> 00:00:04,640
Sepertinya pantat manusia punya standar
keamanan sendiri. Di rumah langsung

2
00:00:04,640 --> 00:00:07,600
lancar, tapi di toilet umum malah mogok
kerja.

3
00:00:08,260 --> 00:00:12,340
Pernah enggak sih, pas di rumah udah
kebelet banget, tapi begitu sampai toilet

4
00:00:12,340 --> 00:00:17,840
umum, eh, malah enggak bisa keluar.
Padahal perut udah mules, keringat udah

5
00:00:17,840 --> 00:00:20,740
bercucuran, tapi si dia malah enggak mau
kerja sama.

6
00:00:21,340 --> 00:00:24,100
Ternyata, ini ada hubungannya sama otak
kita.

7
00:00:24,720 --> 00:00:29,740
Saat di rumah, kita merasa aman dan
nyaman, jadi otot-otot tubuh bisa lebih

8
00:00:29,740 --> 00:00:34,360
rileks dan proses BAB jadi lebih gampang.
Tapi kalau di toilet umum,

9
00:00:34,960 --> 00:00:39,360
ada suara orang lewat, takut pintunya
kebuka, belum lagi kalau ada yang nungguin

10
00:00:39,360 --> 00:00:44,740
di luar. Otak langsung masuk mode waspada
dan otot yang membantu kita BAB bisa ikut

11
00:00:44,740 --> 00:00:45,160
tegang.

12
00:00:45,760 --> 00:00:50,480
Lucunya, kita bukan enggak bisa berak,
kita cuma enggak percaya sama toilet yang

13
00:00:50,480 --> 00:00:56,600
sedang kita duduki. Fenomena ini dikenal
sebagai shy bowel syndrome. Jadi, ternyata

14
00:00:56,600 --> 00:01:01,100
buat bisa berak dengan lancar, kita
enggak cuma butuh toilet, tapi juga rasa

15
00:01:01,100 --> 00:01:04,680
aman dan ketenangan. Pantat juga butuh
privasi, guys.
`;

export type SrtCue = {id: number; start: number; end: number; text: string};

export type CaptionWord = {
  text: string;
  startFrame: number;
  endFrame: number;
};

export type CaptionPage = {
  id: number;
  words: CaptionWord[];
  /** Index kata setelah mana baris baru dibuat (-1 = satu baris). */
  breakAfter: number;
  startFrame: number;
  endFrame: number;
  emphasis: boolean;
};

const parseTimestamp = (t: string): number => {
  const m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(t.trim());
  if (!m) {
    throw new Error(`Timestamp SRT tidak valid: ${t}`);
  }
  return (
    Number(m[1]) * 3600 +
    Number(m[2]) * 60 +
    Number(m[3]) +
    Number(m[4]) / 1000
  );
};

export const parseSrt = (srt: string): SrtCue[] =>
  srt
    .replace(/\r/g, '')
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split('\n');
      const [a, b] = (lines[1] ?? '').split('-->');
      return {
        id: Number(lines[0]),
        start: parseTimestamp(a ?? ''),
        end: parseTimestamp(b ?? ''),
        text: lines.slice(2).join(' ').trim(),
      };
    });

type RawWord = {text: string; start: number; end: number};

// Bobot durasi kata: jumlah huruf + jeda kecil untuk tanda baca.
const weight = (word: string): number => {
  const letters = word.replace(/[.,!?]/g, '').length;
  const pause = /[.!?]$/.test(word) ? 3 : /,$/.test(word) ? 1.5 : 0;
  return Math.max(1, letters + pause);
};

const cueToWords = (cue: SrtCue): RawWord[] => {
  const tokens = cue.text.split(/\s+/).filter(Boolean);
  const weights = tokens.map(weight);
  const total = weights.reduce((a, b) => a + b, 0);
  const span = cue.end - cue.start;
  let acc = 0;
  return tokens.map((text, i) => {
    const start = cue.start + (acc / total) * span;
    acc += weights[i] ?? 1;
    const end = cue.start + (acc / total) * span;
    return {text, start, end};
  });
};

const MAX_WORDS_PER_PAGE = 6;

const findBreak = (words: RawWord[]): number => {
  const total = words.map((w) => w.text).join(' ').length;
  if (total < 24 || words.length < 2) {
    return -1;
  }
  let best = -1;
  let bestDiff = Number.POSITIVE_INFINITY;
  let cum = 0;
  for (let i = 0; i < words.length - 1; i++) {
    cum += (words[i]?.text.length ?? 0) + (i > 0 ? 1 : 0);
    const diff = Math.abs(cum - (total - cum - 1));
    if (diff < bestDiff) {
      bestDiff = diff;
      best = i;
    }
  }
  return best;
};

const buildPages = (cues: SrtCue[]): CaptionPage[] => {
  const all = cues.flatMap(cueToWords);

  // Kelompokkan per kalimat, lalu bagi rata menjadi halaman <= MAX_WORDS_PER_PAGE kata.
  const sentences: RawWord[][] = [];
  let current: RawWord[] = [];
  for (const w of all) {
    current.push(w);
    if (/[.!?]$/.test(w.text)) {
      sentences.push(current);
      current = [];
    }
  }
  if (current.length > 0) {
    sentences.push(current);
  }

  const chunks: RawWord[][] = [];
  for (const s of sentences) {
    const n = Math.ceil(s.length / MAX_WORDS_PER_PAGE);
    const size = Math.ceil(s.length / n);
    for (let i = 0; i < s.length; i += size) {
      chunks.push(s.slice(i, i + size));
    }
  }

  const pages: CaptionPage[] = chunks.map((chunk, idx) => {
    const words: CaptionWord[] = chunk.map((w) => {
      const startFrame = toFrame(w.start);
      return {
        text: w.text,
        startFrame,
        endFrame: Math.max(startFrame + 1, toFrame(w.end)),
      };
    });
    return {
      id: idx,
      words,
      breakAfter: findBreak(chunk),
      startFrame: words[0]?.startFrame ?? 0,
      endFrame: words[words.length - 1]?.endFrame ?? 0,
      emphasis: false,
    };
  });

  // Rapikan akhir halaman: sambung jika jeda pendek, beri tahan singkat jika tidak.
  pages.forEach((page, i) => {
    const next = pages[i + 1];
    if (next) {
      page.endFrame =
        next.startFrame - page.endFrame <= 12 ? next.startFrame : page.endFrame + 4;
    }
  });

  const last = pages[pages.length - 1];
  if (last) {
    last.emphasis = true; // kalimat penutup = subtitle utama
  }
  return pages;
};

export const CAPTION_CUES = parseSrt(SRT_SOURCE);
export const CAPTION_PAGES: CaptionPage[] = buildPages(CAPTION_CUES);
export const LAST_CAPTION_END_FRAME =
  CAPTION_PAGES[CAPTION_PAGES.length - 1]?.endFrame ?? 0;

export const KEYWORDS = new Set([
  'standar',
  'keamanan',
  'umum',
  'waspada',
  'tegang',
  'privasi',
  'shy',
  'bowel',
  'syndrome',
]);
