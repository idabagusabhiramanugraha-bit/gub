// Konfigurasi global video. Semua timing berasal dari sini.

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

/** Satu-satunya offset audio (detik). Geser semua caption + beat jika narasi mulai lebih lambat/cepat. */
export const AUDIO_OFFSET = 0;

/** File narasi di folder public/. GANTI dengan narasi asli. */
export const NARRATION_FILE = 'narasi.mp3';

/** Akhir cue SRT terakhir (detik). Jika narasi asli berbeda, ubah angka ini. */
export const AUDIO_END_SECONDS = 64.68;

/** Freeze frame / jeda setelah narasi selesai. */
export const END_HOLD_SECONDS = 0.5;

export const TOTAL_FRAMES = Math.round(
  (AUDIO_END_SECONDS + AUDIO_OFFSET + END_HOLD_SECONDS) * FPS,
);

export const ENABLE_NARRATION = true;
export const ENABLE_SFX = true;

/** Batas beat dibuat dari SRT per kalimat (estimasi). Set false setelah dicek dengan audio asli. */
export const PROVISIONAL_TIMING = true;

/** Detik -> frame, sudah termasuk AUDIO_OFFSET. */
export const toFrame = (seconds: number): number =>
  Math.round((seconds + AUDIO_OFFSET) * FPS);
