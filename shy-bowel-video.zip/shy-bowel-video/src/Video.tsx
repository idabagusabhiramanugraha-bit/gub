import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {Beat01} from './beats/Beat01';
import {Beat02} from './beats/Beat02';
import {Beat03} from './beats/Beat03';
import {Beat04} from './beats/Beat04';
import {Beat05} from './beats/Beat05';
import {Beat06} from './beats/Beat06';
import {Beat07} from './beats/Beat07';
import {Beat08} from './beats/Beat08';
import {Beat09} from './beats/Beat09';
import {Beat10} from './beats/Beat10';
import {Beat11} from './beats/Beat11';
import {Beat12} from './beats/Beat12';
import type {BeatProps} from './beats/types';
import {SoundEffects} from './components/SoundEffects';
import {Subtitle} from './components/Subtitle';
import {BEAT_TIMING} from './data/beats';
import {ENABLE_NARRATION, NARRATION_FILE, toFrame} from './data/config';

const BEAT_COMPONENTS: Record<number, React.FC<BeatProps>> = {
  1: Beat01,
  2: Beat02,
  3: Beat03,
  4: Beat04,
  5: Beat05,
  6: Beat06,
  7: Beat07,
  8: Beat08,
  9: Beat09,
  10: Beat10,
  11: Beat11,
  12: Beat12,
};

// Tidak ada header, judul permanen, atau indikator progres di video ini.
export const Video: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000', overflow: 'hidden'}}>
    {BEAT_TIMING.map((beat) => {
      const Comp = BEAT_COMPONENTS[beat.id];
      if (!Comp) {
        return null;
      }
      return (
        <Sequence key={beat.id} from={beat.from} durationInFrames={beat.duration} name={`Beat ${beat.id}`}>
          <Comp duration={beat.duration} />
        </Sequence>
      );
    })}

    {ENABLE_NARRATION ? (
      <Sequence from={toFrame(0)} name="Narasi">
        <Audio src={staticFile(NARRATION_FILE)} />
      </Sequence>
    ) : null}

    <SoundEffects />
    <Subtitle />
  </AbsoluteFill>
);
