export const COLORS = {
  ink: '#121212',
  white: '#FFFFFF',
  cream: '#F7E9CF',
  creamDark: '#E8D0A6',
  warmShadow: '#C9A46F',
  lightGray: '#D7DBE1',
  gray: '#A4ABB6',
  darkGray: '#3B4150',
  blue: '#5F82B5',
  blueLight: '#9DB8DD',
  blueDark: '#2D4268',
  yellow: '#FFD93B',
  red: '#E2493F',
  pink: '#F4A6B0',
  pinkLight: '#F9C9D0',
  pinkDark: '#D9748A',
  hair: '#4B2B18',
  hairLight: '#7B4A2B',
  hoodie: '#E4E6EB',
  hoodieShade: '#C2C7D0',
  wood: '#8B6B4A',
} as const;

// Font sistem (tanpa unduhan jaringan saat render).
export const FONT_FAMILY =
  '"Arial Black", "Segoe UI Black", "Trebuchet MS", Impact, "Helvetica Neue", Arial, sans-serif';

/** Outline teks 8 arah dengan text-shadow (lebih konsisten daripada text-stroke). */
export const outlineShadow = (color: string, px: number): string => {
  const dirs: Array<[number, number]> = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
    [1, 1],
    [-1, 1],
    [1, -1],
    [-1, -1],
  ];
  return dirs.map(([dx, dy]) => `${dx * px}px ${dy * px}px 0 ${color}`).join(', ');
};
